(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var value;

var require = meteorInstall({"node_modules":{"meteor":{"appcache":{"appcache-server.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/appcache/appcache-server.js                                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let WebApp;
module.link("meteor/webapp", {
  WebApp(v) {
    WebApp = v;
  }

}, 1);
let crypto;
module.link("crypto", {
  default(v) {
    crypto = v;
  }

}, 2);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 3);
let path;
module.link("path", {
  default(v) {
    path = v;
  }

}, 4);
let _disableSizeCheck = false;
let disabledBrowsers = {};
let enableCallback = null;
Meteor.AppCache = {
  config: options => {
    Object.keys(options).forEach(option => {
      value = options[option];

      if (option === 'browsers') {
        disabledBrowsers = {};
        value.each(browser => disabledBrowsers[browser] = false);
      } else if (option === 'onlineOnly') {
        value.forEach(urlPrefix => RoutePolicy.declare(urlPrefix, 'static-online'));
      } else if (option === 'enableCallback') {
        enableCallback = value;
      } // option to suppress warnings for tests.
      else if (option === '_disableSizeCheck') {
        _disableSizeCheck = value;
      } else if (value === false) {
        disabledBrowsers[option] = true;
      } else if (value === true) {
        disabledBrowsers[option] = false;
      } else {
        throw new Error('Invalid AppCache config option: ' + option);
      }
    });
  }
};

const browserDisabled = request => {
  if (enableCallback) {
    return !enableCallback(request);
  }

  return disabledBrowsers[request.browser.name];
}; // Cache of previously computed app.manifest files.


const manifestCache = new Map();

const shouldSkip = resource => resource.type === 'dynamic js' || resource.type === 'json' && (resource.url.endsWith('.map') || resource.url.endsWith('.stats.json?meteor_js_resource=true'));

WebApp.addHtmlAttributeHook(request => browserDisabled(request) ? null : {
  manifest: "/app.manifest"
});
WebApp.connectHandlers.use((req, res, next) => {
  if (req.url !== '/app.manifest') {
    return next();
  }

  const request = WebApp.categorizeRequest(req); // Browsers will get confused if we unconditionally serve the
  // manifest and then disable the app cache for that browser.  If
  // the app cache had previously been enabled for a browser, it
  // will continue to fetch the manifest as long as it's available,
  // even if we now are not including the manifest attribute in the
  // app HTML.  (Firefox for example will continue to display "this
  // website is asking to store data on your computer for offline
  // use").  Returning a 404 gets the browser to really turn off the
  // app cache.

  if (browserDisabled(request)) {
    res.writeHead(404);
    res.end();
    return;
  }

  const cacheInfo = {
    // Provided by WebApp.categorizeRequest.
    modern: request.modern
  }; // Also provided by WebApp.categorizeRequest.

  cacheInfo.arch = request.arch; // The true hash of the client manifest for this arch, regardless of
  // AUTOUPDATE_VERSION or Autoupdate.autoupdateVersion.

  cacheInfo.clientHash = WebApp.clientHash(cacheInfo.arch);

  if (Package.autoupdate) {
    const {
      // New in Meteor 1.7.1 (autoupdate@1.5.0), this versions object maps
      // client architectures (e.g. "web.browser") to client hashes that
      // reflect AUTOUPDATE_VERSION and Autoupdate.autoupdateVersion.
      versions,
      // The legacy way of forcing a particular version, supported here
      // just in case Autoupdate.versions is not defined.
      autoupdateVersion
    } = Package.autoupdate.Autoupdate;
    const version = versions ? versions[cacheInfo.arch].version : autoupdateVersion;

    if (typeof version === "string" && version !== cacheInfo.clientHash) {
      cacheInfo.autoupdateVersion = version;
    }
  }

  const cacheKey = JSON.stringify(cacheInfo);

  if (!manifestCache.has(cacheKey)) {
    manifestCache.set(cacheKey, computeManifest(cacheInfo));
  }

  const manifest = manifestCache.get(cacheKey);
  res.setHeader('Content-Type', 'text/cache-manifest');
  res.setHeader('Content-Length', manifest.length);
  return res.end(manifest);
});

function computeManifest(cacheInfo) {
  let manifest = "CACHE MANIFEST\n\n"; // After the browser has downloaded the app files from the server and
  // has populated the browser's application cache, the browser will
  // *only* connect to the server and reload the application if the
  // *contents* of the app manifest file has changed.
  //
  // So to ensure that the client updates if client resources change,
  // include a hash of client resources in the manifest.

  manifest += "# ".concat(cacheInfo.clientHash, "\n"); // When using the autoupdate package, also include
  // AUTOUPDATE_VERSION.  Otherwise the client will get into an
  // infinite loop of reloads when the browser doesn't fetch the new
  // app HTML which contains the new version, and autoupdate will
  // reload again trying to get the new code.

  if (typeof cacheInfo.autoupdateVersion === "string") {
    manifest += "# ".concat(cacheInfo.autoupdateVersion, "\n");
  }

  manifest += "\n";
  manifest += "CACHE:\n";
  manifest += "/\n";
  eachResource(cacheInfo, resource => {
    const {
      url
    } = resource;

    if (resource.where !== 'client' || RoutePolicy.classify(url) || shouldSkip(resource)) {
      return;
    }

    manifest += url; // If the resource is not already cacheable (has a query parameter,
    // presumably with a hash or version of some sort), put a version with
    // a hash in the cache.
    //
    // Avoid putting a non-cacheable asset into the cache, otherwise the
    // user can't modify the asset until the cache headers expire.

    if (!resource.cacheable) {
      manifest += "?".concat(resource.hash);
    }

    manifest += "\n";
  });
  manifest += "\n";
  manifest += "FALLBACK:\n";
  manifest += "/ /\n";
  eachResource(cacheInfo, (resource, arch, prefix) => {
    const {
      url
    } = resource;

    if (resource.where !== 'client' || RoutePolicy.classify(url) || shouldSkip(resource)) {
      return;
    }

    if (!resource.cacheable) {
      // Add a fallback entry for each uncacheable asset we added above.
      //
      // This means requests for the bare url ("/image.png" instead of
      // "/image.png?hash") will work offline. Online, however, the
      // browser will send a request to the server. Users can remove this
      // extra request to the server and have the asset served from cache
      // by specifying the full URL with hash in their code (manually,
      // with some sort of URL rewriting helper)
      manifest += "".concat(url, " ").concat(url, "?").concat(resource.hash, "\n");
    }

    if (resource.type === 'asset' && prefix.length > 0 && url.startsWith(prefix)) {
      // If the URL has a prefix like /__browser.legacy or /__cordova, add
      // a fallback from the un-prefixed URL to the fully prefixed URL, so
      // that legacy/cordova browsers can load assets offline without
      // using an explicit prefix. When the client is online, these assets
      // will simply come from the modern web.browser bundle, which does
      // not prefix its asset URLs. Using a fallback rather than just
      // duplicating the resources in the manifest is important because of
      // appcache size limits.
      manifest += "".concat(url.slice(prefix.length), " ").concat(url, "?").concat(resource.hash, "\n");
    }
  });
  manifest += "\n";
  manifest += "NETWORK:\n"; // TODO adding the manifest file to NETWORK should be unnecessary?
  // Want more testing to be sure.

  manifest += "/app.manifest\n";
  [...RoutePolicy.urlPrefixesFor('network'), ...RoutePolicy.urlPrefixesFor('static-online')].forEach(urlPrefix => manifest += "".concat(urlPrefix, "\n"));
  manifest += "*\n"; // content length needs to be based on bytes

  return Buffer.from(manifest, "utf8");
}

function eachResource(_ref, callback) {
  let {
    modern,
    arch
  } = _ref;
  const manifest = WebApp.clientPrograms[arch].manifest;
  let prefix = "";

  if (!modern) {
    manifest.some(_ref2 => {
      let {
        url
      } = _ref2;

      if (url && url.startsWith("/__")) {
        prefix = url.split("/", 2).join("/");
        return true;
      }
    });
  }

  manifest.forEach(resource => {
    callback(resource, arch, prefix);
  });
}

function sizeCheck() {
  const RESOURCE_SIZE_LIMIT = 5 * 1024 * 1024; // 5MB

  const largeSizes = [// Check size of each known architecture independently.
  "web.browser", "web.browser.legacy"].filter(arch => !!WebApp.clientPrograms[arch]).map(arch => {
    let totalSize = 0;
    WebApp.clientPrograms[arch].manifest.forEach(resource => {
      if (resource.where === 'client' && !RoutePolicy.classify(resource.url) && !shouldSkip(resource)) {
        totalSize += resource.size;
      }
    });
    return {
      arch,
      size: totalSize
    };
  }).filter(_ref3 => {
    let {
      size
    } = _ref3;
    return size > RESOURCE_SIZE_LIMIT;
  });

  if (largeSizes.length > 0) {
    Meteor._debug(["** You are using the appcache package, but the size of", "** one or more of your cached resources is larger than", "** the recommended maximum size of 5MB which may break", "** your app in some browsers!", "** ", ...largeSizes.map(data => "** ".concat(data.arch, ": ").concat((data.size / 1024 / 1024).toFixed(1), "MB")), "** ", "** See http://docs.meteor.com/#appcache for more", "** information and fixes."].join("\n"));
  }
} // Run the size check after user code has had a chance to run. That way,
// the size check can take into account files that the user does not
// want cached. Otherwise, the size check warning will still print even
// if the user excludes their large files with
// `Meteor.AppCache.config({onlineOnly: files})`.


Meteor.startup(() => _disableSizeCheck || sizeCheck());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/appcache/appcache-server.js");

/* Exports */
Package._define("appcache", exports);

})();

//# sourceURL=meteor://💻app/packages/appcache.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYXBwY2FjaGUvYXBwY2FjaGUtc2VydmVyLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiV2ViQXBwIiwiY3J5cHRvIiwiZGVmYXVsdCIsImZzIiwicGF0aCIsIl9kaXNhYmxlU2l6ZUNoZWNrIiwiZGlzYWJsZWRCcm93c2VycyIsImVuYWJsZUNhbGxiYWNrIiwiQXBwQ2FjaGUiLCJjb25maWciLCJvcHRpb25zIiwiT2JqZWN0Iiwia2V5cyIsImZvckVhY2giLCJvcHRpb24iLCJ2YWx1ZSIsImVhY2giLCJicm93c2VyIiwidXJsUHJlZml4IiwiUm91dGVQb2xpY3kiLCJkZWNsYXJlIiwiRXJyb3IiLCJicm93c2VyRGlzYWJsZWQiLCJyZXF1ZXN0IiwibmFtZSIsIm1hbmlmZXN0Q2FjaGUiLCJNYXAiLCJzaG91bGRTa2lwIiwicmVzb3VyY2UiLCJ0eXBlIiwidXJsIiwiZW5kc1dpdGgiLCJhZGRIdG1sQXR0cmlidXRlSG9vayIsIm1hbmlmZXN0IiwiY29ubmVjdEhhbmRsZXJzIiwidXNlIiwicmVxIiwicmVzIiwibmV4dCIsImNhdGVnb3JpemVSZXF1ZXN0Iiwid3JpdGVIZWFkIiwiZW5kIiwiY2FjaGVJbmZvIiwibW9kZXJuIiwiYXJjaCIsImNsaWVudEhhc2giLCJQYWNrYWdlIiwiYXV0b3VwZGF0ZSIsInZlcnNpb25zIiwiYXV0b3VwZGF0ZVZlcnNpb24iLCJBdXRvdXBkYXRlIiwidmVyc2lvbiIsImNhY2hlS2V5IiwiSlNPTiIsInN0cmluZ2lmeSIsImhhcyIsInNldCIsImNvbXB1dGVNYW5pZmVzdCIsImdldCIsInNldEhlYWRlciIsImxlbmd0aCIsImVhY2hSZXNvdXJjZSIsIndoZXJlIiwiY2xhc3NpZnkiLCJjYWNoZWFibGUiLCJoYXNoIiwicHJlZml4Iiwic3RhcnRzV2l0aCIsInNsaWNlIiwidXJsUHJlZml4ZXNGb3IiLCJCdWZmZXIiLCJmcm9tIiwiY2FsbGJhY2siLCJjbGllbnRQcm9ncmFtcyIsInNvbWUiLCJzcGxpdCIsImpvaW4iLCJzaXplQ2hlY2siLCJSRVNPVVJDRV9TSVpFX0xJTUlUIiwibGFyZ2VTaXplcyIsImZpbHRlciIsIm1hcCIsInRvdGFsU2l6ZSIsInNpemUiLCJfZGVidWciLCJkYXRhIiwidG9GaXhlZCIsInN0YXJ0dXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUo7QUFBV0gsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUUsTUFBSjtBQUFXSixNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNFLFVBQU0sR0FBQ0YsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1QztBQUErQyxJQUFJSSxFQUFKO0FBQU9OLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLElBQVosRUFBaUI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ0ksTUFBRSxHQUFDSixDQUFIO0FBQUs7O0FBQWpCLENBQWpCLEVBQW9DLENBQXBDO0FBQXVDLElBQUlLLElBQUo7QUFBU1AsTUFBTSxDQUFDQyxJQUFQLENBQVksTUFBWixFQUFtQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDSyxRQUFJLEdBQUNMLENBQUw7QUFBTzs7QUFBbkIsQ0FBbkIsRUFBd0MsQ0FBeEM7QUFNalAsSUFBSU0saUJBQWlCLEdBQUcsS0FBeEI7QUFDQSxJQUFJQyxnQkFBZ0IsR0FBRyxFQUF2QjtBQUNBLElBQUlDLGNBQWMsR0FBRyxJQUFyQjtBQUVBWCxNQUFNLENBQUNZLFFBQVAsR0FBa0I7QUFDaEJDLFFBQU0sRUFBRUMsT0FBTyxJQUFJO0FBQ2pCQyxVQUFNLENBQUNDLElBQVAsQ0FBWUYsT0FBWixFQUFxQkcsT0FBckIsQ0FBNkJDLE1BQU0sSUFBSTtBQUNyQ0MsV0FBSyxHQUFHTCxPQUFPLENBQUNJLE1BQUQsQ0FBZjs7QUFDQSxVQUFJQSxNQUFNLEtBQUssVUFBZixFQUEyQjtBQUN6QlIsd0JBQWdCLEdBQUcsRUFBbkI7QUFDQVMsYUFBSyxDQUFDQyxJQUFOLENBQVdDLE9BQU8sSUFBSVgsZ0JBQWdCLENBQUNXLE9BQUQsQ0FBaEIsR0FBNEIsS0FBbEQ7QUFDRCxPQUhELE1BSUssSUFBSUgsTUFBTSxLQUFLLFlBQWYsRUFBNkI7QUFDaENDLGFBQUssQ0FBQ0YsT0FBTixDQUFjSyxTQUFTLElBQ3JCQyxXQUFXLENBQUNDLE9BQVosQ0FBb0JGLFNBQXBCLEVBQStCLGVBQS9CLENBREY7QUFHRCxPQUpJLE1BS0EsSUFBSUosTUFBTSxLQUFLLGdCQUFmLEVBQWlDO0FBQ3BDUCxzQkFBYyxHQUFHUSxLQUFqQjtBQUNELE9BRkksQ0FHTDtBQUhLLFdBSUEsSUFBSUQsTUFBTSxLQUFLLG1CQUFmLEVBQW9DO0FBQ3ZDVCx5QkFBaUIsR0FBR1UsS0FBcEI7QUFDRCxPQUZJLE1BR0EsSUFBSUEsS0FBSyxLQUFLLEtBQWQsRUFBcUI7QUFDeEJULHdCQUFnQixDQUFDUSxNQUFELENBQWhCLEdBQTJCLElBQTNCO0FBQ0QsT0FGSSxNQUdBLElBQUlDLEtBQUssS0FBSyxJQUFkLEVBQW9CO0FBQ3ZCVCx3QkFBZ0IsQ0FBQ1EsTUFBRCxDQUFoQixHQUEyQixLQUEzQjtBQUNELE9BRkksTUFFRTtBQUNMLGNBQU0sSUFBSU8sS0FBSixDQUFVLHFDQUFxQ1AsTUFBL0MsQ0FBTjtBQUNEO0FBQ0YsS0ExQkQ7QUEyQkQ7QUE3QmUsQ0FBbEI7O0FBZ0NBLE1BQU1RLGVBQWUsR0FBR0MsT0FBTyxJQUFJO0FBQ2pDLE1BQUloQixjQUFKLEVBQW9CO0FBQ2xCLFdBQU8sQ0FBQ0EsY0FBYyxDQUFDZ0IsT0FBRCxDQUF0QjtBQUNEOztBQUVELFNBQU9qQixnQkFBZ0IsQ0FBQ2lCLE9BQU8sQ0FBQ04sT0FBUixDQUFnQk8sSUFBakIsQ0FBdkI7QUFDRCxDQU5ELEMsQ0FRQTs7O0FBQ0EsTUFBTUMsYUFBYSxHQUFHLElBQUlDLEdBQUosRUFBdEI7O0FBRUEsTUFBTUMsVUFBVSxHQUFHQyxRQUFRLElBQ3pCQSxRQUFRLENBQUNDLElBQVQsS0FBa0IsWUFBbEIsSUFDR0QsUUFBUSxDQUFDQyxJQUFULEtBQWtCLE1BQWxCLEtBQ0NELFFBQVEsQ0FBQ0UsR0FBVCxDQUFhQyxRQUFiLENBQXNCLE1BQXRCLEtBQ0FILFFBQVEsQ0FBQ0UsR0FBVCxDQUFhQyxRQUFiLENBQXNCLHFDQUF0QixDQUZELENBRkw7O0FBTUEvQixNQUFNLENBQUNnQyxvQkFBUCxDQUE0QlQsT0FBTyxJQUNqQ0QsZUFBZSxDQUFDQyxPQUFELENBQWYsR0FDRSxJQURGLEdBRUU7QUFBRVUsVUFBUSxFQUFFO0FBQVosQ0FISjtBQU1BakMsTUFBTSxDQUFDa0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkIsQ0FBQ0MsR0FBRCxFQUFNQyxHQUFOLEVBQVdDLElBQVgsS0FBb0I7QUFDN0MsTUFBSUYsR0FBRyxDQUFDTixHQUFKLEtBQVksZUFBaEIsRUFBaUM7QUFDL0IsV0FBT1EsSUFBSSxFQUFYO0FBQ0Q7O0FBRUQsUUFBTWYsT0FBTyxHQUFHdkIsTUFBTSxDQUFDdUMsaUJBQVAsQ0FBeUJILEdBQXpCLENBQWhCLENBTDZDLENBTzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFJZCxlQUFlLENBQUNDLE9BQUQsQ0FBbkIsRUFBOEI7QUFDNUJjLE9BQUcsQ0FBQ0csU0FBSixDQUFjLEdBQWQ7QUFDQUgsT0FBRyxDQUFDSSxHQUFKO0FBQ0E7QUFDRDs7QUFFRCxRQUFNQyxTQUFTLEdBQUc7QUFDaEI7QUFDQUMsVUFBTSxFQUFFcEIsT0FBTyxDQUFDb0I7QUFGQSxHQUFsQixDQXZCNkMsQ0E0QjdDOztBQUNBRCxXQUFTLENBQUNFLElBQVYsR0FBaUJyQixPQUFPLENBQUNxQixJQUF6QixDQTdCNkMsQ0ErQjdDO0FBQ0E7O0FBQ0FGLFdBQVMsQ0FBQ0csVUFBVixHQUF1QjdDLE1BQU0sQ0FBQzZDLFVBQVAsQ0FBa0JILFNBQVMsQ0FBQ0UsSUFBNUIsQ0FBdkI7O0FBRUEsTUFBSUUsT0FBTyxDQUFDQyxVQUFaLEVBQXdCO0FBQ3RCLFVBQU07QUFDSjtBQUNBO0FBQ0E7QUFDQUMsY0FKSTtBQUtKO0FBQ0E7QUFDQUM7QUFQSSxRQVFGSCxPQUFPLENBQUNDLFVBQVIsQ0FBbUJHLFVBUnZCO0FBVUEsVUFBTUMsT0FBTyxHQUFHSCxRQUFRLEdBQ3BCQSxRQUFRLENBQUNOLFNBQVMsQ0FBQ0UsSUFBWCxDQUFSLENBQXlCTyxPQURMLEdBRXBCRixpQkFGSjs7QUFJQSxRQUFJLE9BQU9FLE9BQVAsS0FBbUIsUUFBbkIsSUFDQUEsT0FBTyxLQUFLVCxTQUFTLENBQUNHLFVBRDFCLEVBQ3NDO0FBQ3BDSCxlQUFTLENBQUNPLGlCQUFWLEdBQThCRSxPQUE5QjtBQUNEO0FBQ0Y7O0FBRUQsUUFBTUMsUUFBUSxHQUFHQyxJQUFJLENBQUNDLFNBQUwsQ0FBZVosU0FBZixDQUFqQjs7QUFFQSxNQUFJLENBQUVqQixhQUFhLENBQUM4QixHQUFkLENBQWtCSCxRQUFsQixDQUFOLEVBQW1DO0FBQ2pDM0IsaUJBQWEsQ0FBQytCLEdBQWQsQ0FBa0JKLFFBQWxCLEVBQTRCSyxlQUFlLENBQUNmLFNBQUQsQ0FBM0M7QUFDRDs7QUFFRCxRQUFNVCxRQUFRLEdBQUdSLGFBQWEsQ0FBQ2lDLEdBQWQsQ0FBa0JOLFFBQWxCLENBQWpCO0FBRUFmLEtBQUcsQ0FBQ3NCLFNBQUosQ0FBYyxjQUFkLEVBQThCLHFCQUE5QjtBQUNBdEIsS0FBRyxDQUFDc0IsU0FBSixDQUFjLGdCQUFkLEVBQWdDMUIsUUFBUSxDQUFDMkIsTUFBekM7QUFFQSxTQUFPdkIsR0FBRyxDQUFDSSxHQUFKLENBQVFSLFFBQVIsQ0FBUDtBQUNELENBcEVEOztBQXNFQSxTQUFTd0IsZUFBVCxDQUF5QmYsU0FBekIsRUFBb0M7QUFDbEMsTUFBSVQsUUFBUSxHQUFHLG9CQUFmLENBRGtDLENBR2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBQSxVQUFRLGdCQUFTUyxTQUFTLENBQUNHLFVBQW5CLE9BQVIsQ0FWa0MsQ0FZbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFJLE9BQU9ILFNBQVMsQ0FBQ08saUJBQWpCLEtBQXVDLFFBQTNDLEVBQXFEO0FBQ25EaEIsWUFBUSxnQkFBU1MsU0FBUyxDQUFDTyxpQkFBbkIsT0FBUjtBQUNEOztBQUVEaEIsVUFBUSxJQUFJLElBQVo7QUFFQUEsVUFBUSxJQUFJLFVBQVo7QUFDQUEsVUFBUSxJQUFJLEtBQVo7QUFFQTRCLGNBQVksQ0FBQ25CLFNBQUQsRUFBWWQsUUFBUSxJQUFJO0FBQ2xDLFVBQU07QUFBRUU7QUFBRixRQUFVRixRQUFoQjs7QUFFQSxRQUFJQSxRQUFRLENBQUNrQyxLQUFULEtBQW1CLFFBQW5CLElBQ0EzQyxXQUFXLENBQUM0QyxRQUFaLENBQXFCakMsR0FBckIsQ0FEQSxJQUVBSCxVQUFVLENBQUNDLFFBQUQsQ0FGZCxFQUUwQjtBQUN4QjtBQUNEOztBQUVESyxZQUFRLElBQUlILEdBQVosQ0FUa0MsQ0FXbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUksQ0FBRUYsUUFBUSxDQUFDb0MsU0FBZixFQUEwQjtBQUN4Qi9CLGNBQVEsZUFBUUwsUUFBUSxDQUFDcUMsSUFBakIsQ0FBUjtBQUNEOztBQUVEaEMsWUFBUSxJQUFJLElBQVo7QUFDRCxHQXRCVyxDQUFaO0FBdUJBQSxVQUFRLElBQUksSUFBWjtBQUVBQSxVQUFRLElBQUksYUFBWjtBQUNBQSxVQUFRLElBQUksT0FBWjtBQUNBNEIsY0FBWSxDQUFDbkIsU0FBRCxFQUFZLENBQUNkLFFBQUQsRUFBV2dCLElBQVgsRUFBaUJzQixNQUFqQixLQUE0QjtBQUNsRCxVQUFNO0FBQUVwQztBQUFGLFFBQVVGLFFBQWhCOztBQUVBLFFBQUlBLFFBQVEsQ0FBQ2tDLEtBQVQsS0FBbUIsUUFBbkIsSUFDQTNDLFdBQVcsQ0FBQzRDLFFBQVosQ0FBcUJqQyxHQUFyQixDQURBLElBRUFILFVBQVUsQ0FBQ0MsUUFBRCxDQUZkLEVBRTBCO0FBQ3hCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFFQSxRQUFRLENBQUNvQyxTQUFmLEVBQTBCO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQS9CLGNBQVEsY0FBT0gsR0FBUCxjQUFjQSxHQUFkLGNBQXFCRixRQUFRLENBQUNxQyxJQUE5QixPQUFSO0FBQ0Q7O0FBRUQsUUFBSXJDLFFBQVEsQ0FBQ0MsSUFBVCxLQUFrQixPQUFsQixJQUNBcUMsTUFBTSxDQUFDTixNQUFQLEdBQWdCLENBRGhCLElBRUE5QixHQUFHLENBQUNxQyxVQUFKLENBQWVELE1BQWYsQ0FGSixFQUU0QjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FqQyxjQUFRLGNBQU9ILEdBQUcsQ0FBQ3NDLEtBQUosQ0FBVUYsTUFBTSxDQUFDTixNQUFqQixDQUFQLGNBQW1DOUIsR0FBbkMsY0FBMENGLFFBQVEsQ0FBQ3FDLElBQW5ELE9BQVI7QUFDRDtBQUNGLEdBbENXLENBQVo7QUFvQ0FoQyxVQUFRLElBQUksSUFBWjtBQUVBQSxVQUFRLElBQUksWUFBWixDQTNGa0MsQ0E0RmxDO0FBQ0E7O0FBQ0FBLFVBQVEsSUFBSSxpQkFBWjtBQUNBLEdBQ0UsR0FBR2QsV0FBVyxDQUFDa0QsY0FBWixDQUEyQixTQUEzQixDQURMLEVBRUUsR0FBR2xELFdBQVcsQ0FBQ2tELGNBQVosQ0FBMkIsZUFBM0IsQ0FGTCxFQUdFeEQsT0FIRixDQUdVSyxTQUFTLElBQUllLFFBQVEsY0FBT2YsU0FBUCxPQUgvQjtBQUlBZSxVQUFRLElBQUksS0FBWixDQW5Ha0MsQ0FxR2xDOztBQUNBLFNBQU9xQyxNQUFNLENBQUNDLElBQVAsQ0FBWXRDLFFBQVosRUFBc0IsTUFBdEIsQ0FBUDtBQUNEOztBQUVELFNBQVM0QixZQUFULE9BR0dXLFFBSEgsRUFHYTtBQUFBLE1BSFM7QUFDcEI3QixVQURvQjtBQUVwQkM7QUFGb0IsR0FHVDtBQUNYLFFBQU1YLFFBQVEsR0FBR2pDLE1BQU0sQ0FBQ3lFLGNBQVAsQ0FBc0I3QixJQUF0QixFQUE0QlgsUUFBN0M7QUFFQSxNQUFJaUMsTUFBTSxHQUFHLEVBQWI7O0FBQ0EsTUFBSSxDQUFFdkIsTUFBTixFQUFjO0FBQ1pWLFlBQVEsQ0FBQ3lDLElBQVQsQ0FBYyxTQUFhO0FBQUEsVUFBWjtBQUFFNUM7QUFBRixPQUFZOztBQUN6QixVQUFJQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ3FDLFVBQUosQ0FBZSxLQUFmLENBQVgsRUFBa0M7QUFDaENELGNBQU0sR0FBR3BDLEdBQUcsQ0FBQzZDLEtBQUosQ0FBVSxHQUFWLEVBQWUsQ0FBZixFQUFrQkMsSUFBbEIsQ0FBdUIsR0FBdkIsQ0FBVDtBQUNBLGVBQU8sSUFBUDtBQUNEO0FBQ0YsS0FMRDtBQU1EOztBQUVEM0MsVUFBUSxDQUFDcEIsT0FBVCxDQUFpQmUsUUFBUSxJQUFJO0FBQzNCNEMsWUFBUSxDQUFDNUMsUUFBRCxFQUFXZ0IsSUFBWCxFQUFpQnNCLE1BQWpCLENBQVI7QUFDRCxHQUZEO0FBR0Q7O0FBRUQsU0FBU1csU0FBVCxHQUFxQjtBQUNuQixRQUFNQyxtQkFBbUIsR0FBRyxJQUFJLElBQUosR0FBVyxJQUF2QyxDQURtQixDQUMwQjs7QUFDN0MsUUFBTUMsVUFBVSxHQUFHLENBQUU7QUFDbkIsZUFEaUIsRUFFakIsb0JBRmlCLEVBR2pCQyxNQUhpQixDQUdUcEMsSUFBRCxJQUFVLENBQUMsQ0FBQzVDLE1BQU0sQ0FBQ3lFLGNBQVAsQ0FBc0I3QixJQUF0QixDQUhGLEVBSWxCcUMsR0FKa0IsQ0FJYnJDLElBQUQsSUFBVTtBQUNiLFFBQUlzQyxTQUFTLEdBQUcsQ0FBaEI7QUFFQWxGLFVBQU0sQ0FBQ3lFLGNBQVAsQ0FBc0I3QixJQUF0QixFQUE0QlgsUUFBNUIsQ0FBcUNwQixPQUFyQyxDQUE2Q2UsUUFBUSxJQUFJO0FBQ3ZELFVBQUlBLFFBQVEsQ0FBQ2tDLEtBQVQsS0FBbUIsUUFBbkIsSUFDQSxDQUFFM0MsV0FBVyxDQUFDNEMsUUFBWixDQUFxQm5DLFFBQVEsQ0FBQ0UsR0FBOUIsQ0FERixJQUVBLENBQUVILFVBQVUsQ0FBQ0MsUUFBRCxDQUZoQixFQUU0QjtBQUMxQnNELGlCQUFTLElBQUl0RCxRQUFRLENBQUN1RCxJQUF0QjtBQUNEO0FBQ0YsS0FORDtBQVFBLFdBQU87QUFDTHZDLFVBREs7QUFFTHVDLFVBQUksRUFBRUQ7QUFGRCxLQUFQO0FBSUQsR0FuQmtCLEVBb0JsQkYsTUFwQmtCLENBb0JYO0FBQUEsUUFBQztBQUFFRztBQUFGLEtBQUQ7QUFBQSxXQUFjQSxJQUFJLEdBQUdMLG1CQUFyQjtBQUFBLEdBcEJXLENBQW5COztBQXNCQSxNQUFJQyxVQUFVLENBQUNuQixNQUFYLEdBQW9CLENBQXhCLEVBQTJCO0FBQ3pCaEUsVUFBTSxDQUFDd0YsTUFBUCxDQUFjLENBQ1osd0RBRFksRUFFWix3REFGWSxFQUdaLHdEQUhZLEVBSVosK0JBSlksRUFLWixLQUxZLEVBTVosR0FBR0wsVUFBVSxDQUFDRSxHQUFYLENBQWVJLElBQUksaUJBQVVBLElBQUksQ0FBQ3pDLElBQWYsZUFBd0IsQ0FBQ3lDLElBQUksQ0FBQ0YsSUFBTCxHQUFZLElBQVosR0FBbUIsSUFBcEIsRUFBMEJHLE9BQTFCLENBQWtDLENBQWxDLENBQXhCLE9BQW5CLENBTlMsRUFPWixLQVBZLEVBUVosa0RBUlksRUFTWiwyQkFUWSxFQVVaVixJQVZZLENBVVAsSUFWTyxDQUFkO0FBV0Q7QUFDRixDLENBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0FoRixNQUFNLENBQUMyRixPQUFQLENBQWUsTUFBTWxGLGlCQUFpQixJQUFJd0UsU0FBUyxFQUFuRCxFIiwiZmlsZSI6Ii9wYWNrYWdlcy9hcHBjYWNoZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBXZWJBcHAgfSBmcm9tIFwibWV0ZW9yL3dlYmFwcFwiO1xuaW1wb3J0IGNyeXB0byBmcm9tICdjcnlwdG8nO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuXG5sZXQgX2Rpc2FibGVTaXplQ2hlY2sgPSBmYWxzZTtcbmxldCBkaXNhYmxlZEJyb3dzZXJzID0ge307XG5sZXQgZW5hYmxlQ2FsbGJhY2sgPSBudWxsO1xuXG5NZXRlb3IuQXBwQ2FjaGUgPSB7XG4gIGNvbmZpZzogb3B0aW9ucyA9PiB7XG4gICAgT2JqZWN0LmtleXMob3B0aW9ucykuZm9yRWFjaChvcHRpb24gPT4ge1xuICAgICAgdmFsdWUgPSBvcHRpb25zW29wdGlvbl07XG4gICAgICBpZiAob3B0aW9uID09PSAnYnJvd3NlcnMnKSB7XG4gICAgICAgIGRpc2FibGVkQnJvd3NlcnMgPSB7fTtcbiAgICAgICAgdmFsdWUuZWFjaChicm93c2VyID0+IGRpc2FibGVkQnJvd3NlcnNbYnJvd3Nlcl0gPSBmYWxzZSk7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChvcHRpb24gPT09ICdvbmxpbmVPbmx5Jykge1xuICAgICAgICB2YWx1ZS5mb3JFYWNoKHVybFByZWZpeCA9PlxuICAgICAgICAgIFJvdXRlUG9saWN5LmRlY2xhcmUodXJsUHJlZml4LCAnc3RhdGljLW9ubGluZScpXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChvcHRpb24gPT09ICdlbmFibGVDYWxsYmFjaycpIHtcbiAgICAgICAgZW5hYmxlQ2FsbGJhY2sgPSB2YWx1ZTtcbiAgICAgIH1cbiAgICAgIC8vIG9wdGlvbiB0byBzdXBwcmVzcyB3YXJuaW5ncyBmb3IgdGVzdHMuXG4gICAgICBlbHNlIGlmIChvcHRpb24gPT09ICdfZGlzYWJsZVNpemVDaGVjaycpIHtcbiAgICAgICAgX2Rpc2FibGVTaXplQ2hlY2sgPSB2YWx1ZTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYgKHZhbHVlID09PSBmYWxzZSkge1xuICAgICAgICBkaXNhYmxlZEJyb3dzZXJzW29wdGlvbl0gPSB0cnVlO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAodmFsdWUgPT09IHRydWUpIHtcbiAgICAgICAgZGlzYWJsZWRCcm93c2Vyc1tvcHRpb25dID0gZmFsc2U7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgQXBwQ2FjaGUgY29uZmlnIG9wdGlvbjogJyArIG9wdGlvbik7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn07XG5cbmNvbnN0IGJyb3dzZXJEaXNhYmxlZCA9IHJlcXVlc3QgPT4ge1xuICBpZiAoZW5hYmxlQ2FsbGJhY2spIHtcbiAgICByZXR1cm4gIWVuYWJsZUNhbGxiYWNrKHJlcXVlc3QpO1xuICB9XG5cbiAgcmV0dXJuIGRpc2FibGVkQnJvd3NlcnNbcmVxdWVzdC5icm93c2VyLm5hbWVdO1xufVxuXG4vLyBDYWNoZSBvZiBwcmV2aW91c2x5IGNvbXB1dGVkIGFwcC5tYW5pZmVzdCBmaWxlcy5cbmNvbnN0IG1hbmlmZXN0Q2FjaGUgPSBuZXcgTWFwO1xuXG5jb25zdCBzaG91bGRTa2lwID0gcmVzb3VyY2UgPT5cbiAgcmVzb3VyY2UudHlwZSA9PT0gJ2R5bmFtaWMganMnIHx8XG4gICAgKHJlc291cmNlLnR5cGUgPT09ICdqc29uJyAmJlxuICAgICAocmVzb3VyY2UudXJsLmVuZHNXaXRoKCcubWFwJykgfHxcbiAgICAgIHJlc291cmNlLnVybC5lbmRzV2l0aCgnLnN0YXRzLmpzb24/bWV0ZW9yX2pzX3Jlc291cmNlPXRydWUnKSkpO1xuXG5XZWJBcHAuYWRkSHRtbEF0dHJpYnV0ZUhvb2socmVxdWVzdCA9PlxuICBicm93c2VyRGlzYWJsZWQocmVxdWVzdCkgP1xuICAgIG51bGwgOlxuICAgIHsgbWFuaWZlc3Q6IFwiL2FwcC5tYW5pZmVzdFwiIH1cbik7XG5cbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKChyZXEsIHJlcywgbmV4dCkgPT4ge1xuICBpZiAocmVxLnVybCAhPT0gJy9hcHAubWFuaWZlc3QnKSB7XG4gICAgcmV0dXJuIG5leHQoKTtcbiAgfVxuXG4gIGNvbnN0IHJlcXVlc3QgPSBXZWJBcHAuY2F0ZWdvcml6ZVJlcXVlc3QocmVxKTtcblxuICAvLyBCcm93c2VycyB3aWxsIGdldCBjb25mdXNlZCBpZiB3ZSB1bmNvbmRpdGlvbmFsbHkgc2VydmUgdGhlXG4gIC8vIG1hbmlmZXN0IGFuZCB0aGVuIGRpc2FibGUgdGhlIGFwcCBjYWNoZSBmb3IgdGhhdCBicm93c2VyLiAgSWZcbiAgLy8gdGhlIGFwcCBjYWNoZSBoYWQgcHJldmlvdXNseSBiZWVuIGVuYWJsZWQgZm9yIGEgYnJvd3NlciwgaXRcbiAgLy8gd2lsbCBjb250aW51ZSB0byBmZXRjaCB0aGUgbWFuaWZlc3QgYXMgbG9uZyBhcyBpdCdzIGF2YWlsYWJsZSxcbiAgLy8gZXZlbiBpZiB3ZSBub3cgYXJlIG5vdCBpbmNsdWRpbmcgdGhlIG1hbmlmZXN0IGF0dHJpYnV0ZSBpbiB0aGVcbiAgLy8gYXBwIEhUTUwuICAoRmlyZWZveCBmb3IgZXhhbXBsZSB3aWxsIGNvbnRpbnVlIHRvIGRpc3BsYXkgXCJ0aGlzXG4gIC8vIHdlYnNpdGUgaXMgYXNraW5nIHRvIHN0b3JlIGRhdGEgb24geW91ciBjb21wdXRlciBmb3Igb2ZmbGluZVxuICAvLyB1c2VcIikuICBSZXR1cm5pbmcgYSA0MDQgZ2V0cyB0aGUgYnJvd3NlciB0byByZWFsbHkgdHVybiBvZmYgdGhlXG4gIC8vIGFwcCBjYWNoZS5cblxuICBpZiAoYnJvd3NlckRpc2FibGVkKHJlcXVlc3QpKSB7XG4gICAgcmVzLndyaXRlSGVhZCg0MDQpO1xuICAgIHJlcy5lbmQoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBjYWNoZUluZm8gPSB7XG4gICAgLy8gUHJvdmlkZWQgYnkgV2ViQXBwLmNhdGVnb3JpemVSZXF1ZXN0LlxuICAgIG1vZGVybjogcmVxdWVzdC5tb2Rlcm4sXG4gIH07XG5cbiAgLy8gQWxzbyBwcm92aWRlZCBieSBXZWJBcHAuY2F0ZWdvcml6ZVJlcXVlc3QuXG4gIGNhY2hlSW5mby5hcmNoID0gcmVxdWVzdC5hcmNoO1xuXG4gIC8vIFRoZSB0cnVlIGhhc2ggb2YgdGhlIGNsaWVudCBtYW5pZmVzdCBmb3IgdGhpcyBhcmNoLCByZWdhcmRsZXNzIG9mXG4gIC8vIEFVVE9VUERBVEVfVkVSU0lPTiBvciBBdXRvdXBkYXRlLmF1dG91cGRhdGVWZXJzaW9uLlxuICBjYWNoZUluZm8uY2xpZW50SGFzaCA9IFdlYkFwcC5jbGllbnRIYXNoKGNhY2hlSW5mby5hcmNoKTtcblxuICBpZiAoUGFja2FnZS5hdXRvdXBkYXRlKSB7XG4gICAgY29uc3Qge1xuICAgICAgLy8gTmV3IGluIE1ldGVvciAxLjcuMSAoYXV0b3VwZGF0ZUAxLjUuMCksIHRoaXMgdmVyc2lvbnMgb2JqZWN0IG1hcHNcbiAgICAgIC8vIGNsaWVudCBhcmNoaXRlY3R1cmVzIChlLmcuIFwid2ViLmJyb3dzZXJcIikgdG8gY2xpZW50IGhhc2hlcyB0aGF0XG4gICAgICAvLyByZWZsZWN0IEFVVE9VUERBVEVfVkVSU0lPTiBhbmQgQXV0b3VwZGF0ZS5hdXRvdXBkYXRlVmVyc2lvbi5cbiAgICAgIHZlcnNpb25zLFxuICAgICAgLy8gVGhlIGxlZ2FjeSB3YXkgb2YgZm9yY2luZyBhIHBhcnRpY3VsYXIgdmVyc2lvbiwgc3VwcG9ydGVkIGhlcmVcbiAgICAgIC8vIGp1c3QgaW4gY2FzZSBBdXRvdXBkYXRlLnZlcnNpb25zIGlzIG5vdCBkZWZpbmVkLlxuICAgICAgYXV0b3VwZGF0ZVZlcnNpb24sXG4gICAgfSA9IFBhY2thZ2UuYXV0b3VwZGF0ZS5BdXRvdXBkYXRlO1xuXG4gICAgY29uc3QgdmVyc2lvbiA9IHZlcnNpb25zXG4gICAgICA/IHZlcnNpb25zW2NhY2hlSW5mby5hcmNoXS52ZXJzaW9uXG4gICAgICA6IGF1dG91cGRhdGVWZXJzaW9uO1xuXG4gICAgaWYgKHR5cGVvZiB2ZXJzaW9uID09PSBcInN0cmluZ1wiICYmXG4gICAgICAgIHZlcnNpb24gIT09IGNhY2hlSW5mby5jbGllbnRIYXNoKSB7XG4gICAgICBjYWNoZUluZm8uYXV0b3VwZGF0ZVZlcnNpb24gPSB2ZXJzaW9uO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGNhY2hlS2V5ID0gSlNPTi5zdHJpbmdpZnkoY2FjaGVJbmZvKTtcblxuICBpZiAoISBtYW5pZmVzdENhY2hlLmhhcyhjYWNoZUtleSkpIHtcbiAgICBtYW5pZmVzdENhY2hlLnNldChjYWNoZUtleSwgY29tcHV0ZU1hbmlmZXN0KGNhY2hlSW5mbykpO1xuICB9XG5cbiAgY29uc3QgbWFuaWZlc3QgPSBtYW5pZmVzdENhY2hlLmdldChjYWNoZUtleSk7XG5cbiAgcmVzLnNldEhlYWRlcignQ29udGVudC1UeXBlJywgJ3RleHQvY2FjaGUtbWFuaWZlc3QnKTtcbiAgcmVzLnNldEhlYWRlcignQ29udGVudC1MZW5ndGgnLCBtYW5pZmVzdC5sZW5ndGgpO1xuXG4gIHJldHVybiByZXMuZW5kKG1hbmlmZXN0KTtcbn0pO1xuXG5mdW5jdGlvbiBjb21wdXRlTWFuaWZlc3QoY2FjaGVJbmZvKSB7XG4gIGxldCBtYW5pZmVzdCA9IFwiQ0FDSEUgTUFOSUZFU1RcXG5cXG5cIjtcblxuICAvLyBBZnRlciB0aGUgYnJvd3NlciBoYXMgZG93bmxvYWRlZCB0aGUgYXBwIGZpbGVzIGZyb20gdGhlIHNlcnZlciBhbmRcbiAgLy8gaGFzIHBvcHVsYXRlZCB0aGUgYnJvd3NlcidzIGFwcGxpY2F0aW9uIGNhY2hlLCB0aGUgYnJvd3NlciB3aWxsXG4gIC8vICpvbmx5KiBjb25uZWN0IHRvIHRoZSBzZXJ2ZXIgYW5kIHJlbG9hZCB0aGUgYXBwbGljYXRpb24gaWYgdGhlXG4gIC8vICpjb250ZW50cyogb2YgdGhlIGFwcCBtYW5pZmVzdCBmaWxlIGhhcyBjaGFuZ2VkLlxuICAvL1xuICAvLyBTbyB0byBlbnN1cmUgdGhhdCB0aGUgY2xpZW50IHVwZGF0ZXMgaWYgY2xpZW50IHJlc291cmNlcyBjaGFuZ2UsXG4gIC8vIGluY2x1ZGUgYSBoYXNoIG9mIGNsaWVudCByZXNvdXJjZXMgaW4gdGhlIG1hbmlmZXN0LlxuICBtYW5pZmVzdCArPSBgIyAke2NhY2hlSW5mby5jbGllbnRIYXNofVxcbmA7XG5cbiAgLy8gV2hlbiB1c2luZyB0aGUgYXV0b3VwZGF0ZSBwYWNrYWdlLCBhbHNvIGluY2x1ZGVcbiAgLy8gQVVUT1VQREFURV9WRVJTSU9OLiAgT3RoZXJ3aXNlIHRoZSBjbGllbnQgd2lsbCBnZXQgaW50byBhblxuICAvLyBpbmZpbml0ZSBsb29wIG9mIHJlbG9hZHMgd2hlbiB0aGUgYnJvd3NlciBkb2Vzbid0IGZldGNoIHRoZSBuZXdcbiAgLy8gYXBwIEhUTUwgd2hpY2ggY29udGFpbnMgdGhlIG5ldyB2ZXJzaW9uLCBhbmQgYXV0b3VwZGF0ZSB3aWxsXG4gIC8vIHJlbG9hZCBhZ2FpbiB0cnlpbmcgdG8gZ2V0IHRoZSBuZXcgY29kZS5cbiAgaWYgKHR5cGVvZiBjYWNoZUluZm8uYXV0b3VwZGF0ZVZlcnNpb24gPT09IFwic3RyaW5nXCIpIHtcbiAgICBtYW5pZmVzdCArPSBgIyAke2NhY2hlSW5mby5hdXRvdXBkYXRlVmVyc2lvbn1cXG5gO1xuICB9XG5cbiAgbWFuaWZlc3QgKz0gXCJcXG5cIjtcblxuICBtYW5pZmVzdCArPSBcIkNBQ0hFOlxcblwiO1xuICBtYW5pZmVzdCArPSBcIi9cXG5cIjtcblxuICBlYWNoUmVzb3VyY2UoY2FjaGVJbmZvLCByZXNvdXJjZSA9PiB7XG4gICAgY29uc3QgeyB1cmwgfSA9IHJlc291cmNlO1xuXG4gICAgaWYgKHJlc291cmNlLndoZXJlICE9PSAnY2xpZW50JyB8fFxuICAgICAgICBSb3V0ZVBvbGljeS5jbGFzc2lmeSh1cmwpIHx8XG4gICAgICAgIHNob3VsZFNraXAocmVzb3VyY2UpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgbWFuaWZlc3QgKz0gdXJsO1xuXG4gICAgLy8gSWYgdGhlIHJlc291cmNlIGlzIG5vdCBhbHJlYWR5IGNhY2hlYWJsZSAoaGFzIGEgcXVlcnkgcGFyYW1ldGVyLFxuICAgIC8vIHByZXN1bWFibHkgd2l0aCBhIGhhc2ggb3IgdmVyc2lvbiBvZiBzb21lIHNvcnQpLCBwdXQgYSB2ZXJzaW9uIHdpdGhcbiAgICAvLyBhIGhhc2ggaW4gdGhlIGNhY2hlLlxuICAgIC8vXG4gICAgLy8gQXZvaWQgcHV0dGluZyBhIG5vbi1jYWNoZWFibGUgYXNzZXQgaW50byB0aGUgY2FjaGUsIG90aGVyd2lzZSB0aGVcbiAgICAvLyB1c2VyIGNhbid0IG1vZGlmeSB0aGUgYXNzZXQgdW50aWwgdGhlIGNhY2hlIGhlYWRlcnMgZXhwaXJlLlxuICAgIGlmICghIHJlc291cmNlLmNhY2hlYWJsZSkge1xuICAgICAgbWFuaWZlc3QgKz0gYD8ke3Jlc291cmNlLmhhc2h9YDtcbiAgICB9XG5cbiAgICBtYW5pZmVzdCArPSBcIlxcblwiO1xuICB9KTtcbiAgbWFuaWZlc3QgKz0gXCJcXG5cIjtcblxuICBtYW5pZmVzdCArPSBcIkZBTExCQUNLOlxcblwiO1xuICBtYW5pZmVzdCArPSBcIi8gL1xcblwiO1xuICBlYWNoUmVzb3VyY2UoY2FjaGVJbmZvLCAocmVzb3VyY2UsIGFyY2gsIHByZWZpeCkgPT4ge1xuICAgIGNvbnN0IHsgdXJsIH0gPSByZXNvdXJjZTtcblxuICAgIGlmIChyZXNvdXJjZS53aGVyZSAhPT0gJ2NsaWVudCcgfHxcbiAgICAgICAgUm91dGVQb2xpY3kuY2xhc3NpZnkodXJsKSB8fFxuICAgICAgICBzaG91bGRTa2lwKHJlc291cmNlKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICghIHJlc291cmNlLmNhY2hlYWJsZSkge1xuICAgICAgLy8gQWRkIGEgZmFsbGJhY2sgZW50cnkgZm9yIGVhY2ggdW5jYWNoZWFibGUgYXNzZXQgd2UgYWRkZWQgYWJvdmUuXG4gICAgICAvL1xuICAgICAgLy8gVGhpcyBtZWFucyByZXF1ZXN0cyBmb3IgdGhlIGJhcmUgdXJsIChcIi9pbWFnZS5wbmdcIiBpbnN0ZWFkIG9mXG4gICAgICAvLyBcIi9pbWFnZS5wbmc/aGFzaFwiKSB3aWxsIHdvcmsgb2ZmbGluZS4gT25saW5lLCBob3dldmVyLCB0aGVcbiAgICAgIC8vIGJyb3dzZXIgd2lsbCBzZW5kIGEgcmVxdWVzdCB0byB0aGUgc2VydmVyLiBVc2VycyBjYW4gcmVtb3ZlIHRoaXNcbiAgICAgIC8vIGV4dHJhIHJlcXVlc3QgdG8gdGhlIHNlcnZlciBhbmQgaGF2ZSB0aGUgYXNzZXQgc2VydmVkIGZyb20gY2FjaGVcbiAgICAgIC8vIGJ5IHNwZWNpZnlpbmcgdGhlIGZ1bGwgVVJMIHdpdGggaGFzaCBpbiB0aGVpciBjb2RlIChtYW51YWxseSxcbiAgICAgIC8vIHdpdGggc29tZSBzb3J0IG9mIFVSTCByZXdyaXRpbmcgaGVscGVyKVxuICAgICAgbWFuaWZlc3QgKz0gYCR7dXJsfSAke3VybH0/JHtyZXNvdXJjZS5oYXNofVxcbmA7XG4gICAgfVxuXG4gICAgaWYgKHJlc291cmNlLnR5cGUgPT09ICdhc3NldCcgJiZcbiAgICAgICAgcHJlZml4Lmxlbmd0aCA+IDAgJiZcbiAgICAgICAgdXJsLnN0YXJ0c1dpdGgocHJlZml4KSkge1xuICAgICAgLy8gSWYgdGhlIFVSTCBoYXMgYSBwcmVmaXggbGlrZSAvX19icm93c2VyLmxlZ2FjeSBvciAvX19jb3Jkb3ZhLCBhZGRcbiAgICAgIC8vIGEgZmFsbGJhY2sgZnJvbSB0aGUgdW4tcHJlZml4ZWQgVVJMIHRvIHRoZSBmdWxseSBwcmVmaXhlZCBVUkwsIHNvXG4gICAgICAvLyB0aGF0IGxlZ2FjeS9jb3Jkb3ZhIGJyb3dzZXJzIGNhbiBsb2FkIGFzc2V0cyBvZmZsaW5lIHdpdGhvdXRcbiAgICAgIC8vIHVzaW5nIGFuIGV4cGxpY2l0IHByZWZpeC4gV2hlbiB0aGUgY2xpZW50IGlzIG9ubGluZSwgdGhlc2UgYXNzZXRzXG4gICAgICAvLyB3aWxsIHNpbXBseSBjb21lIGZyb20gdGhlIG1vZGVybiB3ZWIuYnJvd3NlciBidW5kbGUsIHdoaWNoIGRvZXNcbiAgICAgIC8vIG5vdCBwcmVmaXggaXRzIGFzc2V0IFVSTHMuIFVzaW5nIGEgZmFsbGJhY2sgcmF0aGVyIHRoYW4ganVzdFxuICAgICAgLy8gZHVwbGljYXRpbmcgdGhlIHJlc291cmNlcyBpbiB0aGUgbWFuaWZlc3QgaXMgaW1wb3J0YW50IGJlY2F1c2Ugb2ZcbiAgICAgIC8vIGFwcGNhY2hlIHNpemUgbGltaXRzLlxuICAgICAgbWFuaWZlc3QgKz0gYCR7dXJsLnNsaWNlKHByZWZpeC5sZW5ndGgpfSAke3VybH0/JHtyZXNvdXJjZS5oYXNofVxcbmA7XG4gICAgfVxuICB9KTtcblxuICBtYW5pZmVzdCArPSBcIlxcblwiO1xuXG4gIG1hbmlmZXN0ICs9IFwiTkVUV09SSzpcXG5cIjtcbiAgLy8gVE9ETyBhZGRpbmcgdGhlIG1hbmlmZXN0IGZpbGUgdG8gTkVUV09SSyBzaG91bGQgYmUgdW5uZWNlc3Nhcnk/XG4gIC8vIFdhbnQgbW9yZSB0ZXN0aW5nIHRvIGJlIHN1cmUuXG4gIG1hbmlmZXN0ICs9IFwiL2FwcC5tYW5pZmVzdFxcblwiO1xuICBbXG4gICAgLi4uUm91dGVQb2xpY3kudXJsUHJlZml4ZXNGb3IoJ25ldHdvcmsnKSxcbiAgICAuLi5Sb3V0ZVBvbGljeS51cmxQcmVmaXhlc0Zvcignc3RhdGljLW9ubGluZScpXG4gIF0uZm9yRWFjaCh1cmxQcmVmaXggPT4gbWFuaWZlc3QgKz0gYCR7dXJsUHJlZml4fVxcbmApO1xuICBtYW5pZmVzdCArPSBcIipcXG5cIjtcblxuICAvLyBjb250ZW50IGxlbmd0aCBuZWVkcyB0byBiZSBiYXNlZCBvbiBieXRlc1xuICByZXR1cm4gQnVmZmVyLmZyb20obWFuaWZlc3QsIFwidXRmOFwiKTtcbn1cblxuZnVuY3Rpb24gZWFjaFJlc291cmNlKHtcbiAgbW9kZXJuLFxuICBhcmNoLFxufSwgY2FsbGJhY2spIHtcbiAgY29uc3QgbWFuaWZlc3QgPSBXZWJBcHAuY2xpZW50UHJvZ3JhbXNbYXJjaF0ubWFuaWZlc3Q7XG5cbiAgbGV0IHByZWZpeCA9IFwiXCI7XG4gIGlmICghIG1vZGVybikge1xuICAgIG1hbmlmZXN0LnNvbWUoKHsgdXJsIH0pID0+IHtcbiAgICAgIGlmICh1cmwgJiYgdXJsLnN0YXJ0c1dpdGgoXCIvX19cIikpIHtcbiAgICAgICAgcHJlZml4ID0gdXJsLnNwbGl0KFwiL1wiLCAyKS5qb2luKFwiL1wiKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBtYW5pZmVzdC5mb3JFYWNoKHJlc291cmNlID0+IHtcbiAgICBjYWxsYmFjayhyZXNvdXJjZSwgYXJjaCwgcHJlZml4KTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHNpemVDaGVjaygpIHtcbiAgY29uc3QgUkVTT1VSQ0VfU0laRV9MSU1JVCA9IDUgKiAxMDI0ICogMTAyNDsgLy8gNU1CXG4gIGNvbnN0IGxhcmdlU2l6ZXMgPSBbIC8vIENoZWNrIHNpemUgb2YgZWFjaCBrbm93biBhcmNoaXRlY3R1cmUgaW5kZXBlbmRlbnRseS5cbiAgICBcIndlYi5icm93c2VyXCIsXG4gICAgXCJ3ZWIuYnJvd3Nlci5sZWdhY3lcIixcbiAgXS5maWx0ZXIoKGFyY2gpID0+ICEhV2ViQXBwLmNsaWVudFByb2dyYW1zW2FyY2hdKVxuICAubWFwKChhcmNoKSA9PiB7XG4gICAgbGV0IHRvdGFsU2l6ZSA9IDA7XG5cbiAgICBXZWJBcHAuY2xpZW50UHJvZ3JhbXNbYXJjaF0ubWFuaWZlc3QuZm9yRWFjaChyZXNvdXJjZSA9PiB7XG4gICAgICBpZiAocmVzb3VyY2Uud2hlcmUgPT09ICdjbGllbnQnICYmXG4gICAgICAgICAgISBSb3V0ZVBvbGljeS5jbGFzc2lmeShyZXNvdXJjZS51cmwpICYmXG4gICAgICAgICAgISBzaG91bGRTa2lwKHJlc291cmNlKSkge1xuICAgICAgICB0b3RhbFNpemUgKz0gcmVzb3VyY2Uuc2l6ZTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHJldHVybiB7XG4gICAgICBhcmNoLFxuICAgICAgc2l6ZTogdG90YWxTaXplLFxuICAgIH1cbiAgfSlcbiAgLmZpbHRlcigoeyBzaXplIH0pID0+IHNpemUgPiBSRVNPVVJDRV9TSVpFX0xJTUlUKTtcblxuICBpZiAobGFyZ2VTaXplcy5sZW5ndGggPiAwKSB7XG4gICAgTWV0ZW9yLl9kZWJ1ZyhbXG4gICAgICBcIioqIFlvdSBhcmUgdXNpbmcgdGhlIGFwcGNhY2hlIHBhY2thZ2UsIGJ1dCB0aGUgc2l6ZSBvZlwiLFxuICAgICAgXCIqKiBvbmUgb3IgbW9yZSBvZiB5b3VyIGNhY2hlZCByZXNvdXJjZXMgaXMgbGFyZ2VyIHRoYW5cIixcbiAgICAgIFwiKiogdGhlIHJlY29tbWVuZGVkIG1heGltdW0gc2l6ZSBvZiA1TUIgd2hpY2ggbWF5IGJyZWFrXCIsXG4gICAgICBcIioqIHlvdXIgYXBwIGluIHNvbWUgYnJvd3NlcnMhXCIsXG4gICAgICBcIioqIFwiLFxuICAgICAgLi4ubGFyZ2VTaXplcy5tYXAoZGF0YSA9PiBgKiogJHtkYXRhLmFyY2h9OiAkeyhkYXRhLnNpemUgLyAxMDI0IC8gMTAyNCkudG9GaXhlZCgxKX1NQmApLFxuICAgICAgXCIqKiBcIixcbiAgICAgIFwiKiogU2VlIGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vI2FwcGNhY2hlIGZvciBtb3JlXCIsXG4gICAgICBcIioqIGluZm9ybWF0aW9uIGFuZCBmaXhlcy5cIlxuICAgIF0uam9pbihcIlxcblwiKSk7XG4gIH1cbn1cblxuLy8gUnVuIHRoZSBzaXplIGNoZWNrIGFmdGVyIHVzZXIgY29kZSBoYXMgaGFkIGEgY2hhbmNlIHRvIHJ1bi4gVGhhdCB3YXksXG4vLyB0aGUgc2l6ZSBjaGVjayBjYW4gdGFrZSBpbnRvIGFjY291bnQgZmlsZXMgdGhhdCB0aGUgdXNlciBkb2VzIG5vdFxuLy8gd2FudCBjYWNoZWQuIE90aGVyd2lzZSwgdGhlIHNpemUgY2hlY2sgd2FybmluZyB3aWxsIHN0aWxsIHByaW50IGV2ZW5cbi8vIGlmIHRoZSB1c2VyIGV4Y2x1ZGVzIHRoZWlyIGxhcmdlIGZpbGVzIHdpdGhcbi8vIGBNZXRlb3IuQXBwQ2FjaGUuY29uZmlnKHtvbmxpbmVPbmx5OiBmaWxlc30pYC5cbk1ldGVvci5zdGFydHVwKCgpID0+IF9kaXNhYmxlU2l6ZUNoZWNrIHx8IHNpemVDaGVjaygpKTtcbiJdfQ==
