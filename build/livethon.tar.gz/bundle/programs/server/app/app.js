var require = meteorInstall({"imports":{"api":{"methods":{"addSessionUser.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/methods/addSessionUser.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  addSessionUser: () => addSessionUser
});
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let SessionsCollection;
module.link("../modules", {
  SessionsCollection(v) {
    SessionsCollection = v;
  }

}, 2);
const addSessionUser = {
  name: 'session.adduser',

  // Factor out validation so that it can be run independently (1)
  validate(args) {
    new SimpleSchema({
      session: {
        type: String
      }
    }).validate(args);
  },

  // Factor out Method body so that it can be called independently (3)
  run(_ref) {
    let {
      session
    } = _ref;
    const sessionData = SessionsCollection.findOne({
      name: session
    });

    if (!sessionData) {
      throw new Meteor.Error('session.adduser.session_not_found', 'Cannot give join non-existent session');
    }

    if (sessionData.users.includes(this.userId)) {
      throw new Meteor.Error('session.adduser.duplicate', 'User already member of session');
    }

    SessionsCollection.update({
      name: session
    }, {
      $addToSet: {
        users: this.userId
      }
    });
  },

  // Call Method by referencing the JS object (4)
  // Also, this lets us specify Meteor.apply options once in
  // the Method implementation, rather than requiring the caller
  // to specify it at the call site.
  call(args, callback) {
    const options = {
      returnStubValue: true,
      // (5)
      throwStubExceptions: true // (6)

    };
    Meteor.apply(this.name, [args], options, callback);
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"createFeedback.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/methods/createFeedback.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  module1.export({
    createFeedback: () => createFeedback
  });
  let SimpleSchema;
  module1.link("simpl-schema", {
    default(v) {
      SimpleSchema = v;
    }

  }, 0);
  let Meteor;
  module1.link("meteor/meteor", {
    Meteor(v) {
      Meteor = v;
    }

  }, 1);
  let FeedbackCollection, ModulesCollection;
  module1.link("../modules", {
    FeedbackCollection(v) {
      FeedbackCollection = v;
    },

    ModulesCollection(v) {
      ModulesCollection = v;
    }

  }, 2);
  let Roles;
  module1.link("meteor/alanning:roles", {
    Roles(v) {
      Roles = v;
    }

  }, 3);
  const createFeedback = {
    name: 'feedback.create',

    // Factor out validation so that it can be run independently (1)
    validate(args) {// TODO: fix schema to validate highlighted regions
      // new SimpleSchema({
      //   moduleID: { type: String },
      //   message: { type: String },
      //   snapshot: { type: String },
      //   createdAt: { type: Date },
      // }).validate(args)
    },

    // Factor out Method body so that it can be called independently (3)
    run(_ref) {
      let {
        body,
        moduleID,
        snapshotID,
        selectedRegions,
        createdAt
      } = _ref;
      const module = ModulesCollection.findOne({
        _id: moduleID
      });

      if (!Roles.userIsInRole(this.userId, 'instructor')) {
        throw new Meteor.Error('run.create.unauthorized', 'Cannot create feedback that is not yours');
      }

      if (!module) {
        throw new Meteor.Error('feedback.create.module_not_found', 'Cannot give feedback to non-existent module');
      }

      const data = {
        body: body,
        module: moduleID,
        // TODO: is this necessary when snapshot is provided?
        snapshot: snapshotID,
        region: selectedRegions,
        createdAt
      };
      FeedbackCollection.insert(data);
    },

    // Call Method by referencing the JS object (4)
    // Also, this lets us specify Meteor.apply options once in
    // the Method implementation, rather than requiring the caller
    // to specify it at the call site.
    call(args, callback) {
      const options = {
        returnStubValue: true,
        // (5)
        throwStubExceptions: true // (6)

      };
      Meteor.apply(this.name, [args], options, callback);
    }

  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"createModule.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/methods/createModule.js                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  createModule: () => createModule
});
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let ModulesCollection, RunsCollection;
module.link("../modules", {
  ModulesCollection(v) {
    ModulesCollection = v;
  },

  RunsCollection(v) {
    RunsCollection = v;
  }

}, 2);
const createModule = {
  name: 'modules.create',

  // Factor out validation so that it can be run independently (1)
  validate(args) {
    new SimpleSchema({
      code: {
        type: String
      },
      createdAt: {
        type: Date
      },
      session: {
        type: String
      }
    }).validate(args);
  },

  // Factor out Method body so that it can be called independently (3)
  run(_ref) {
    let {
      code,
      createdAt,
      session
    } = _ref;
    ModulesCollection.insert({
      code,
      createdAt,
      user: this.userId,
      session
    });
  },

  // Call Method by referencing the JS object (4)
  // Also, this lets us specify Meteor.apply options once in
  // the Method implementation, rather than requiring the caller
  // to specify it at the call site.
  call(args, callback) {
    const options = {
      returnStubValue: true,
      // (5)
      throwStubExceptions: true // (6)

    };
    Meteor.apply(this.name, [args], options, callback);
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"createRun.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/methods/createRun.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  module1.export({
    createRun: () => createRun
  });
  let SimpleSchema;
  module1.link("simpl-schema", {
    default(v) {
      SimpleSchema = v;
    }

  }, 0);
  let Meteor;
  module1.link("meteor/meteor", {
    Meteor(v) {
      Meteor = v;
    }

  }, 1);
  let ModulesCollection, RunsCollection;
  module1.link("../modules", {
    ModulesCollection(v) {
      ModulesCollection = v;
    },

    RunsCollection(v) {
      RunsCollection = v;
    }

  }, 2);
  const createRun = {
    name: 'runs.create',

    // Factor out validation so that it can be run independently (1)
    validate(args) {
      new SimpleSchema({
        moduleID: {
          type: String
        },
        input: {
          type: String
        },
        output: {
          type: String
        },
        createdAt: {
          type: Date
        }
      }).validate(args);
    },

    // Factor out Method body so that it can be called independently (3)
    run(_ref) {
      let {
        moduleID,
        input,
        output,
        createdAt
      } = _ref;
      const module = ModulesCollection.findOne({
        _id: moduleID
      });

      if (!module) {
        throw new Meteor.Error('run.create.module_not_found', 'Referenced module is not found');
      }

      if (module.user != this.userId) {
        throw new Meteor.Error('run.create.unauthorized', 'Cannot reference module that is not yours');
      }

      RunsCollection.insert({
        module: moduleID,
        input,
        output,
        createdAt
      });
    },

    // Call Method by referencing the JS object (4)
    // Also, this lets us specify Meteor.apply options once in
    // the Method implementation, rather than requiring the caller
    // to specify it at the call site.
    call(args, callback) {
      const options = {
        returnStubValue: true,
        // (5)
        throwStubExceptions: true // (6)

      };
      Meteor.apply(this.name, [args], options, callback);
    }

  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"createSession.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/methods/createSession.js                                                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  createSession: () => createSession
});
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let SessionsCollection;
module.link("../modules", {
  SessionsCollection(v) {
    SessionsCollection = v;
  }

}, 2);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 3);
const createSession = {
  name: 'session.create',

  // Factor out validation so that it can be run independently (1)
  validate(args) {
    new SimpleSchema({
      name: {
        type: String
      },
      title: {
        type: String
      },
      description: {
        type: String
      },
      template: {
        type: String
      },
      createdAt: {
        type: Date
      }
    }).validate(args);
  },

  // Factor out Method body so that it can be called independently (3)
  run(_ref) {
    let {
      name,
      title,
      description,
      template,
      createdAt
    } = _ref;

    if (!Roles.userIsInRole(this.userId, 'instructor')) {
      throw new Meteor.Error('session.create.unauthorized', 'Only users with role instructor can create sessions');
    }

    if (SessionsCollection.find({
      name
    }).fetch().length > 0) {
      throw new Meteor.Error('session.create.duplicate', 'Session name already taken');
    }

    SessionsCollection.insert({
      name: name,
      instructions: {
        title,
        description
      },
      template,
      users: [],
      createdAt
    });
  },

  // Call Method by referencing the JS object (4)
  // Also, this lets us specify Meteor.apply options once in
  // the Method implementation, rather than requiring the caller
  // to specify it at the call site.
  call(args, callback) {
    const options = {
      returnStubValue: true,
      // (5)
      throwStubExceptions: true // (6)

    };
    Meteor.apply(this.name, [args], options, callback);
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"createSnapshot.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/methods/createSnapshot.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  createSnapshot: () => createSnapshot
});
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let SnapshotsCollection, SessionsCollection;
module.link("../modules", {
  SnapshotsCollection(v) {
    SnapshotsCollection = v;
  },

  SessionsCollection(v) {
    SessionsCollection = v;
  }

}, 2);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 3);
const createSnapshot = {
  name: 'snapshots.create',

  // Factor out validation so that it can be run independently (1)
  validate(args) {
    new SimpleSchema({
      code: {
        type: String
      },
      session: {
        type: String
      },
      user: {
        type: String
      },
      createdAt: {
        type: Date
      }
    }).validate(args);
  },

  // Factor out Method body so that it can be called independently (3)
  run(_ref) {
    let {
      code,
      session,
      user,
      createdAt
    } = _ref;

    if (SessionsCollection.find({
      name: session
    }).fetch().length == 0) {
      throw new Meteor.Error('snapshots.create.session_not_found', 'Referenced session is not found');
    }

    if (user != this.userId && !Roles.userIsInRole(this.userId, 'instructor')) {
      throw new Meteor.Error('run.create.unauthorized', 'Cannot create snapshot that is not yours with current permissions');
    }

    SnapshotsCollection.insert({
      code,
      session,
      user,
      createdAt
    });
  },

  // Call Method by referencing the JS object (4)
  // Also, this lets us specify Meteor.apply options once in
  // the Method implementation, rather than requiring the caller
  // to specify it at the call site.
  call(args, callback) {
    const options = {
      returnStubValue: true,
      // (5)
      throwStubExceptions: true // (6)

    };
    Meteor.apply(this.name, [args], options, callback);
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rateFeedback.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/methods/rateFeedback.js                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  module1.export({
    rateFeedback: () => rateFeedback
  });
  let SimpleSchema;
  module1.link("simpl-schema", {
    default(v) {
      SimpleSchema = v;
    }

  }, 0);
  let Meteor;
  module1.link("meteor/meteor", {
    Meteor(v) {
      Meteor = v;
    }

  }, 1);
  let FeedbackCollection, ModulesCollection;
  module1.link("../modules", {
    FeedbackCollection(v) {
      FeedbackCollection = v;
    },

    ModulesCollection(v) {
      ModulesCollection = v;
    }

  }, 2);
  const rateFeedback = {
    name: 'feedback.rate',

    // Factor out validation so that it can be run independently (1)
    validate(args) {
      new SimpleSchema({
        feedbackID: {
          type: String
        },
        rating: {
          type: Boolean
        },
        createdAt: {
          type: Date
        }
      }).validate(args);
    },

    // Factor out Method body so that it can be called independently (3)
    run(_ref) {
      let {
        feedbackID,
        rating,
        createdAt
      } = _ref;
      const feedback = FeedbackCollection.findOne({
        _id: feedbackID
      });
      const moduleID = feedback.module;
      const module = ModulesCollection.findOne({
        _id: moduleID
      });
      const owner = module.user;

      if (owner != this.userId) {
        throw new Meteor.Error('feedback.rate.unauthorized', 'Cannot rate feedback intended for users other than yourself');
      }

      FeedbackCollection.update({
        _id: feedbackID
      }, {
        $set: {
          helpful: rating,
          ratedAt: createdAt
        }
      });
    },

    // Call Method by referencing the JS object (4)
    // Also, this lets us specify Meteor.apply options once in
    // the Method implementation, rather than requiring the caller
    // to specify it at the call site.
    call(args, callback) {
      const options = {
        returnStubValue: true,
        // (5)
        throwStubExceptions: true // (6)

      };
      Meteor.apply(this.name, [args], options, callback);
    }

  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"updateModule.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/methods/updateModule.js                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  module1.export({
    updateModule: () => updateModule
  });
  let SimpleSchema;
  module1.link("simpl-schema", {
    default(v) {
      SimpleSchema = v;
    }

  }, 0);
  let Meteor;
  module1.link("meteor/meteor", {
    Meteor(v) {
      Meteor = v;
    }

  }, 1);
  let ModulesCollection;
  module1.link("../modules", {
    ModulesCollection(v) {
      ModulesCollection = v;
    }

  }, 2);
  const updateModule = {
    name: 'modules.update',

    // Factor out validation so that it can be run independently (1)
    validate(args) {
      new SimpleSchema({
        moduleID: {
          type: String
        },
        code: {
          type: String
        },
        createdAt: {
          type: Date
        }
      }).validate(args);
    },

    // Factor out Method body so that it can be called independently (3)
    run(_ref) {
      let {
        moduleID,
        code,
        createdAt
      } = _ref;
      const module = ModulesCollection.findOne({
        _id: moduleID
      });

      if (module.user != this.userId) {
        throw new Meteor.Error('modules.update.unauthorized', 'Cannot edit module that is not yours');
      }

      ModulesCollection.update({
        _id: moduleID
      }, {
        $set: {
          code,
          createdAt
        }
      });
    },

    // Call Method by referencing the JS object (4)
    // Also, this lets us specify Meteor.apply options once in
    // the Method implementation, rather than requiring the caller
    // to specify it at the call site.
    call(args, callback) {
      const options = {
        returnStubValue: true,
        // (5)
        throwStubExceptions: true // (6)

      };
      Meteor.apply(this.name, [args], options, callback);
    }

  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"modules.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/modules.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  SessionsCollection: () => SessionsCollection,
  SnapshotsCollection: () => SnapshotsCollection,
  ModulesCollection: () => ModulesCollection,
  RunsCollection: () => RunsCollection,
  FeedbackCollection: () => FeedbackCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const SessionsCollection = new Mongo.Collection('sessions');
const SnapshotsCollection = new Mongo.Collection('snapshots');
const ModulesCollection = new Mongo.Collection('modules');
const RunsCollection = new Mongo.Collection('runs');
const FeedbackCollection = new Mongo.Collection('feedback');
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  module1.export({
    INSTRUCTOR: () => INSTRUCTOR
  });
  let Meteor;
  module1.link("meteor/meteor", {
    Meteor(v) {
      Meteor = v;
    }

  }, 0);
  let Accounts;
  module1.link("meteor/accounts-base", {
    Accounts(v) {
      Accounts = v;
    }

  }, 1);
  let RunsCollection, ModulesCollection, SnapshotsCollection, FeedbackCollection, SessionsCollection;
  module1.link("../imports/api/modules", {
    RunsCollection(v) {
      RunsCollection = v;
    },

    ModulesCollection(v) {
      ModulesCollection = v;
    },

    SnapshotsCollection(v) {
      SnapshotsCollection = v;
    },

    FeedbackCollection(v) {
      FeedbackCollection = v;
    },

    SessionsCollection(v) {
      SessionsCollection = v;
    }

  }, 2);
  let Roles;
  module1.link("meteor/alanning:roles", {
    Roles(v) {
      Roles = v;
    }

  }, 3);
  let createFeedback;
  module1.link("../imports/api/methods/createFeedback", {
    createFeedback(v) {
      createFeedback = v;
    }

  }, 4);
  let createModule;
  module1.link("../imports/api/methods/createModule", {
    createModule(v) {
      createModule = v;
    }

  }, 5);
  let createRun;
  module1.link("../imports/api/methods/createRun", {
    createRun(v) {
      createRun = v;
    }

  }, 6);
  let createSession;
  module1.link("../imports/api/methods/createSession", {
    createSession(v) {
      createSession = v;
    }

  }, 7);
  let createSnapshot;
  module1.link("../imports/api/methods/createSnapshot", {
    createSnapshot(v) {
      createSnapshot = v;
    }

  }, 8);
  let rateFeedback;
  module1.link("../imports/api/methods/rateFeedback", {
    rateFeedback(v) {
      rateFeedback = v;
    }

  }, 9);
  let updateModule;
  module1.link("../imports/api/methods/updateModule", {
    updateModule(v) {
      updateModule = v;
    }

  }, 10);
  let addSessionUser;
  module1.link("../imports/api/methods/addSessionUser", {
    addSessionUser(v) {
      addSessionUser = v;
    }

  }, 11);
  const INSTRUCTOR = "instructor";
  const STUDENTS = [];
  Meteor.startup(() => {
    // TODO: Why include empty array of students???
    [...STUDENTS, INSTRUCTOR].forEach(name => {
      if (!Accounts.findUserByUsername(name)) {
        Accounts.createUser({
          username: name,
          password: "password"
        });
      }
    }); // create roles

    if (!Meteor.roles.findOne({
      _id: 'student'
    })) {
      Roles.createRole('student');
    }

    if (!Meteor.roles.findOne({
      _id: 'instructor'
    })) {
      Roles.createRole('instructor');
    } // assign roles


    const instructorID = Meteor.users.findOne({
      username: "instructor"
    })._id;

    Roles.addUsersToRoles(instructorID, 'instructor'); // prevent direct client-side database access
    // Meteor recommends to use Methods instead for security

    ModulesCollection.deny({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    SessionsCollection.deny({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    SnapshotsCollection.deny({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    FeedbackCollection.deny({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    RunsCollection.deny({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    Meteor.publish('userData', function () {
      return Meteor.users.find({}, {
        fields: {
          username: 1,
          createdAt: 1,
          _id: 1
        }
      });
    });
    Meteor.publish('sessions', function () {
      return SessionsCollection.find();
    });
    Meteor.publish('modules', function () {
      const userID = this.userId; // if instructor, return all modules, else only return modules owned by user making the request

      return ModulesCollection.find(Roles.userIsInRole(this.userId, 'instructor') ? {} : {
        user: userID
      });
    });
    Meteor.publish('runs', function () {
      const userID = this.userId; // if instructor, return all runs, else only return modules owned by user making the request

      const modules = ModulesCollection.find(Roles.userIsInRole(this.userId, 'instructor') ? {} : {
        user: userID
      }).fetch();
      return RunsCollection.find({
        module: {
          $in: modules.map(module => module._id)
        }
      });
    });
    Meteor.publish('snapshots', function () {
      const userID = this.userId; // if instructor, return all snapshots, else only return modules owned by user making the request

      return SnapshotsCollection.find(Roles.userIsInRole(this.userId, 'instructor') ? {} : {
        user: userID
      });
    });
    Meteor.publish('feedback', function () {
      const userID = this.userId;
      const studentModules = ModulesCollection.find({
        user: userID
      }).fetch();
      return FeedbackCollection.find(Roles.userIsInRole(this.userId, 'instructor') ? {} : {
        module: {
          $in: studentModules.map(m => m._id)
        }
      });
    }); // Very helpful for getting started with Meteor Methods https://guide.meteor.com/methods.html#advanced-boilerplate

    const methods = [createFeedback, createModule, createRun, createSession, createSnapshot, rateFeedback, updateModule, addSessionUser];
    methods.forEach(method => {
      // register each method with Meteor's DDP system
      Meteor.methods({
        [method.name]: function (args) {
          method.validate.call(this, args);
          method.run.call(this, args);
        }
      });
    });
  });
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs",
    ".ts",
    ".jsx",
    ".tsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hZGRTZXNzaW9uVXNlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9jcmVhdGVGZWVkYmFjay5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9jcmVhdGVNb2R1bGUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21ldGhvZHMvY3JlYXRlUnVuLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2NyZWF0ZVNlc3Npb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21ldGhvZHMvY3JlYXRlU25hcHNob3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21ldGhvZHMvcmF0ZUZlZWRiYWNrLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL3VwZGF0ZU1vZHVsZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbW9kdWxlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiYWRkU2Vzc2lvblVzZXIiLCJTaW1wbGVTY2hlbWEiLCJsaW5rIiwiZGVmYXVsdCIsInYiLCJNZXRlb3IiLCJTZXNzaW9uc0NvbGxlY3Rpb24iLCJuYW1lIiwidmFsaWRhdGUiLCJhcmdzIiwic2Vzc2lvbiIsInR5cGUiLCJTdHJpbmciLCJydW4iLCJzZXNzaW9uRGF0YSIsImZpbmRPbmUiLCJFcnJvciIsInVzZXJzIiwiaW5jbHVkZXMiLCJ1c2VySWQiLCJ1cGRhdGUiLCIkYWRkVG9TZXQiLCJjYWxsIiwiY2FsbGJhY2siLCJvcHRpb25zIiwicmV0dXJuU3R1YlZhbHVlIiwidGhyb3dTdHViRXhjZXB0aW9ucyIsImFwcGx5IiwibW9kdWxlMSIsImNyZWF0ZUZlZWRiYWNrIiwiRmVlZGJhY2tDb2xsZWN0aW9uIiwiTW9kdWxlc0NvbGxlY3Rpb24iLCJSb2xlcyIsImJvZHkiLCJtb2R1bGVJRCIsInNuYXBzaG90SUQiLCJzZWxlY3RlZFJlZ2lvbnMiLCJjcmVhdGVkQXQiLCJfaWQiLCJ1c2VySXNJblJvbGUiLCJkYXRhIiwic25hcHNob3QiLCJyZWdpb24iLCJpbnNlcnQiLCJjcmVhdGVNb2R1bGUiLCJSdW5zQ29sbGVjdGlvbiIsImNvZGUiLCJEYXRlIiwidXNlciIsImNyZWF0ZVJ1biIsImlucHV0Iiwib3V0cHV0IiwiY3JlYXRlU2Vzc2lvbiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJ0ZW1wbGF0ZSIsImZpbmQiLCJmZXRjaCIsImxlbmd0aCIsImluc3RydWN0aW9ucyIsImNyZWF0ZVNuYXBzaG90IiwiU25hcHNob3RzQ29sbGVjdGlvbiIsInJhdGVGZWVkYmFjayIsImZlZWRiYWNrSUQiLCJyYXRpbmciLCJCb29sZWFuIiwiZmVlZGJhY2siLCJvd25lciIsIiRzZXQiLCJoZWxwZnVsIiwicmF0ZWRBdCIsInVwZGF0ZU1vZHVsZSIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIklOU1RSVUNUT1IiLCJBY2NvdW50cyIsIlNUVURFTlRTIiwic3RhcnR1cCIsImZvckVhY2giLCJmaW5kVXNlckJ5VXNlcm5hbWUiLCJjcmVhdGVVc2VyIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsInJvbGVzIiwiY3JlYXRlUm9sZSIsImluc3RydWN0b3JJRCIsImFkZFVzZXJzVG9Sb2xlcyIsImRlbnkiLCJyZW1vdmUiLCJwdWJsaXNoIiwiZmllbGRzIiwidXNlcklEIiwibW9kdWxlcyIsIiRpbiIsIm1hcCIsInN0dWRlbnRNb2R1bGVzIiwibSIsIm1ldGhvZHMiLCJtZXRob2QiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLGdCQUFjLEVBQUMsTUFBSUE7QUFBcEIsQ0FBZDtBQUFtRCxJQUFJQyxZQUFKO0FBQWlCSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNILGdCQUFZLEdBQUNHLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSUMsTUFBSjtBQUFXUCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNHLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJRSxrQkFBSjtBQUF1QlIsTUFBTSxDQUFDSSxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDSSxvQkFBa0IsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLHNCQUFrQixHQUFDRixDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBekIsRUFBdUUsQ0FBdkU7QUFLL00sTUFBTUosY0FBYyxHQUFHO0FBQzVCTyxNQUFJLEVBQUUsaUJBRHNCOztBQUc1QjtBQUNBQyxVQUFRLENBQUNDLElBQUQsRUFBTztBQUNiLFFBQUlSLFlBQUosQ0FBaUI7QUFDZlMsYUFBTyxFQUFFO0FBQUVDLFlBQUksRUFBRUM7QUFBUjtBQURNLEtBQWpCLEVBRUdKLFFBRkgsQ0FFWUMsSUFGWjtBQUdELEdBUjJCOztBQVU1QjtBQUNBSSxLQUFHLE9BQWM7QUFBQSxRQUFiO0FBQUVIO0FBQUYsS0FBYTtBQUVmLFVBQU1JLFdBQVcsR0FBR1Isa0JBQWtCLENBQUNTLE9BQW5CLENBQTJCO0FBQUVSLFVBQUksRUFBRUc7QUFBUixLQUEzQixDQUFwQjs7QUFFQSxRQUFJLENBQUNJLFdBQUwsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1csS0FBWCxDQUFpQixtQ0FBakIsRUFDTix1Q0FETSxDQUFOO0FBRUg7O0FBRUQsUUFBSUYsV0FBVyxDQUFDRyxLQUFaLENBQWtCQyxRQUFsQixDQUEyQixLQUFLQyxNQUFoQyxDQUFKLEVBQTZDO0FBQ3pDLFlBQU0sSUFBSWQsTUFBTSxDQUFDVyxLQUFYLENBQWlCLDJCQUFqQixFQUNOLGdDQURNLENBQU47QUFFSDs7QUFFRFYsc0JBQWtCLENBQUNjLE1BQW5CLENBQTBCO0FBQUViLFVBQUksRUFBRUc7QUFBUixLQUExQixFQUE2QztBQUN6Q1csZUFBUyxFQUFFO0FBQUVKLGFBQUssRUFBRSxLQUFLRTtBQUFkO0FBRDhCLEtBQTdDO0FBSUQsR0E3QjJCOztBQStCNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQUcsTUFBSSxDQUFDYixJQUFELEVBQU9jLFFBQVAsRUFBaUI7QUFDbkIsVUFBTUMsT0FBTyxHQUFHO0FBQ2RDLHFCQUFlLEVBQUUsSUFESDtBQUNhO0FBQzNCQyx5QkFBbUIsRUFBRSxJQUZQLENBRWE7O0FBRmIsS0FBaEI7QUFLQXJCLFVBQU0sQ0FBQ3NCLEtBQVAsQ0FBYSxLQUFLcEIsSUFBbEIsRUFBd0IsQ0FBQ0UsSUFBRCxDQUF4QixFQUFnQ2UsT0FBaEMsRUFBeUNELFFBQXpDO0FBQ0Q7O0FBMUMyQixDQUF2QixDOzs7Ozs7Ozs7Ozs7QUNMUEssU0FBTyxDQUFDN0IsTUFBUixDQUFlO0FBQUM4QixrQkFBYyxFQUFDLE1BQUlBO0FBQXBCLEdBQWY7QUFBb0QsTUFBSTVCLFlBQUo7QUFBaUIyQixTQUFPLENBQUMxQixJQUFSLENBQWEsY0FBYixFQUE0QjtBQUFDQyxXQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSCxrQkFBWSxHQUFDRyxDQUFiO0FBQWU7O0FBQTNCLEdBQTVCLEVBQXlELENBQXpEO0FBQTRELE1BQUlDLE1BQUo7QUFBV3VCLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxlQUFiLEVBQTZCO0FBQUNHLFVBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFlBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixHQUE3QixFQUFtRCxDQUFuRDtBQUFzRCxNQUFJMEIsa0JBQUosRUFBdUJDLGlCQUF2QjtBQUF5Q0gsU0FBTyxDQUFDMUIsSUFBUixDQUFhLFlBQWIsRUFBMEI7QUFBQzRCLHNCQUFrQixDQUFDMUIsQ0FBRCxFQUFHO0FBQUMwQix3QkFBa0IsR0FBQzFCLENBQW5CO0FBQXFCLEtBQTVDOztBQUE2QzJCLHFCQUFpQixDQUFDM0IsQ0FBRCxFQUFHO0FBQUMyQix1QkFBaUIsR0FBQzNCLENBQWxCO0FBQW9COztBQUF0RixHQUExQixFQUFrSCxDQUFsSDtBQUFxSCxNQUFJNEIsS0FBSjtBQUFVSixTQUFPLENBQUMxQixJQUFSLENBQWEsdUJBQWIsRUFBcUM7QUFBQzhCLFNBQUssQ0FBQzVCLENBQUQsRUFBRztBQUFDNEIsV0FBSyxHQUFDNUIsQ0FBTjtBQUFROztBQUFsQixHQUFyQyxFQUF5RCxDQUF6RDtBQUtuVyxRQUFNeUIsY0FBYyxHQUFHO0FBQzVCdEIsUUFBSSxFQUFFLGlCQURzQjs7QUFHNUI7QUFDQUMsWUFBUSxDQUFDQyxJQUFELEVBQU8sQ0FDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNELEtBWjJCOztBQWM1QjtBQUNBSSxPQUFHLE9BQTZEO0FBQUEsVUFBNUQ7QUFBRW9CLFlBQUY7QUFBUUMsZ0JBQVI7QUFBa0JDLGtCQUFsQjtBQUE4QkMsdUJBQTlCO0FBQStDQztBQUEvQyxPQUE0RDtBQUU5RCxZQUFNdkMsTUFBTSxHQUFHaUMsaUJBQWlCLENBQUNoQixPQUFsQixDQUEwQjtBQUFFdUIsV0FBRyxFQUFFSjtBQUFQLE9BQTFCLENBQWY7O0FBRUEsVUFBSSxDQUFDRixLQUFLLENBQUNPLFlBQU4sQ0FBbUIsS0FBS3BCLE1BQXhCLEVBQWdDLFlBQWhDLENBQUwsRUFBb0Q7QUFDbEQsY0FBTSxJQUFJZCxNQUFNLENBQUNXLEtBQVgsQ0FBaUIseUJBQWpCLEVBQ0osMENBREksQ0FBTjtBQUVEOztBQUVELFVBQUksQ0FBQ2xCLE1BQUwsRUFBYTtBQUNYLGNBQU0sSUFBSU8sTUFBTSxDQUFDVyxLQUFYLENBQWlCLGtDQUFqQixFQUNKLDZDQURJLENBQU47QUFFRDs7QUFFRCxZQUFNd0IsSUFBSSxHQUFHO0FBQ1hQLFlBQUksRUFBRUEsSUFESztBQUVYbkMsY0FBTSxFQUFFb0MsUUFGRztBQUVPO0FBQ2xCTyxnQkFBUSxFQUFFTixVQUhDO0FBSVhPLGNBQU0sRUFBRU4sZUFKRztBQUtYQztBQUxXLE9BQWI7QUFRQVAsd0JBQWtCLENBQUNhLE1BQW5CLENBQTBCSCxJQUExQjtBQUVELEtBdkMyQjs7QUF5QzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0FsQixRQUFJLENBQUNiLElBQUQsRUFBT2MsUUFBUCxFQUFpQjtBQUNuQixZQUFNQyxPQUFPLEdBQUc7QUFDZEMsdUJBQWUsRUFBRSxJQURIO0FBQ2E7QUFDM0JDLDJCQUFtQixFQUFFLElBRlAsQ0FFYTs7QUFGYixPQUFoQjtBQUtBckIsWUFBTSxDQUFDc0IsS0FBUCxDQUFhLEtBQUtwQixJQUFsQixFQUF3QixDQUFDRSxJQUFELENBQXhCLEVBQWdDZSxPQUFoQyxFQUF5Q0QsUUFBekM7QUFDRDs7QUFwRDJCLEdBQXZCOzs7Ozs7Ozs7Ozs7QUNMUHpCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUM2QyxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJM0MsWUFBSjtBQUFpQkgsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSCxnQkFBWSxHQUFDRyxDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUlDLE1BQUo7QUFBV1AsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRyxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTJCLGlCQUFKLEVBQXNCYyxjQUF0QjtBQUFxQy9DLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQzZCLG1CQUFpQixDQUFDM0IsQ0FBRCxFQUFHO0FBQUMyQixxQkFBaUIsR0FBQzNCLENBQWxCO0FBQW9CLEdBQTFDOztBQUEyQ3lDLGdCQUFjLENBQUN6QyxDQUFELEVBQUc7QUFBQ3lDLGtCQUFjLEdBQUN6QyxDQUFmO0FBQWlCOztBQUE5RSxDQUF6QixFQUF5RyxDQUF6RztBQUl6TixNQUFNd0MsWUFBWSxHQUFHO0FBQ3hCckMsTUFBSSxFQUFFLGdCQURrQjs7QUFHeEI7QUFDQUMsVUFBUSxDQUFDQyxJQUFELEVBQU87QUFDWCxRQUFJUixZQUFKLENBQWlCO0FBQ2I2QyxVQUFJLEVBQUU7QUFBRW5DLFlBQUksRUFBRUM7QUFBUixPQURPO0FBRWJ5QixlQUFTLEVBQUU7QUFBRTFCLFlBQUksRUFBRW9DO0FBQVIsT0FGRTtBQUdickMsYUFBTyxFQUFFO0FBQUVDLFlBQUksRUFBRUM7QUFBUjtBQUhJLEtBQWpCLEVBSUdKLFFBSkgsQ0FJWUMsSUFKWjtBQUtILEdBVnVCOztBQVl4QjtBQUNBSSxLQUFHLE9BQStCO0FBQUEsUUFBOUI7QUFBRWlDLFVBQUY7QUFBUVQsZUFBUjtBQUFtQjNCO0FBQW5CLEtBQThCO0FBQzlCcUIscUJBQWlCLENBQUNZLE1BQWxCLENBQXlCO0FBQ3JCRyxVQURxQjtBQUVyQlQsZUFGcUI7QUFHckJXLFVBQUksRUFBRSxLQUFLN0IsTUFIVTtBQUlyQlQ7QUFKcUIsS0FBekI7QUFNSCxHQXBCdUI7O0FBc0J4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBWSxNQUFJLENBQUNiLElBQUQsRUFBT2MsUUFBUCxFQUFpQjtBQUNqQixVQUFNQyxPQUFPLEdBQUc7QUFDWkMscUJBQWUsRUFBRSxJQURMO0FBQ2U7QUFDM0JDLHlCQUFtQixFQUFFLElBRlQsQ0FFZTs7QUFGZixLQUFoQjtBQUtBckIsVUFBTSxDQUFDc0IsS0FBUCxDQUFhLEtBQUtwQixJQUFsQixFQUF3QixDQUFDRSxJQUFELENBQXhCLEVBQWdDZSxPQUFoQyxFQUF5Q0QsUUFBekM7QUFFSDs7QUFsQ3VCLENBQXJCLEM7Ozs7Ozs7Ozs7OztBQ0pQSyxTQUFPLENBQUM3QixNQUFSLENBQWU7QUFBQ2tELGFBQVMsRUFBQyxNQUFJQTtBQUFmLEdBQWY7QUFBMEMsTUFBSWhELFlBQUo7QUFBaUIyQixTQUFPLENBQUMxQixJQUFSLENBQWEsY0FBYixFQUE0QjtBQUFDQyxXQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSCxrQkFBWSxHQUFDRyxDQUFiO0FBQWU7O0FBQTNCLEdBQTVCLEVBQXlELENBQXpEO0FBQTRELE1BQUlDLE1BQUo7QUFBV3VCLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxlQUFiLEVBQTZCO0FBQUNHLFVBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFlBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixHQUE3QixFQUFtRCxDQUFuRDtBQUFzRCxNQUFJMkIsaUJBQUosRUFBc0JjLGNBQXRCO0FBQXFDakIsU0FBTyxDQUFDMUIsSUFBUixDQUFhLFlBQWIsRUFBMEI7QUFBQzZCLHFCQUFpQixDQUFDM0IsQ0FBRCxFQUFHO0FBQUMyQix1QkFBaUIsR0FBQzNCLENBQWxCO0FBQW9CLEtBQTFDOztBQUEyQ3lDLGtCQUFjLENBQUN6QyxDQUFELEVBQUc7QUFBQ3lDLG9CQUFjLEdBQUN6QyxDQUFmO0FBQWlCOztBQUE5RSxHQUExQixFQUEwRyxDQUExRztBQUl0TixRQUFNNkMsU0FBUyxHQUFHO0FBQ3ZCMUMsUUFBSSxFQUFFLGFBRGlCOztBQUd2QjtBQUNBQyxZQUFRLENBQUNDLElBQUQsRUFBTztBQUNiLFVBQUlSLFlBQUosQ0FBaUI7QUFDZmlDLGdCQUFRLEVBQUU7QUFBRXZCLGNBQUksRUFBRUM7QUFBUixTQURLO0FBRWZzQyxhQUFLLEVBQUU7QUFBRXZDLGNBQUksRUFBRUM7QUFBUixTQUZRO0FBR2Z1QyxjQUFNLEVBQUU7QUFBRXhDLGNBQUksRUFBRUM7QUFBUixTQUhPO0FBSWZ5QixpQkFBUyxFQUFFO0FBQUUxQixjQUFJLEVBQUVvQztBQUFSO0FBSkksT0FBakIsRUFLR3ZDLFFBTEgsQ0FLWUMsSUFMWjtBQU1ELEtBWHNCOztBQWF2QjtBQUNBSSxPQUFHLE9BQXlDO0FBQUEsVUFBeEM7QUFBRXFCLGdCQUFGO0FBQVlnQixhQUFaO0FBQW1CQyxjQUFuQjtBQUEyQmQ7QUFBM0IsT0FBd0M7QUFFMUMsWUFBTXZDLE1BQU0sR0FBR2lDLGlCQUFpQixDQUFDaEIsT0FBbEIsQ0FBMEI7QUFBRXVCLFdBQUcsRUFBRUo7QUFBUCxPQUExQixDQUFmOztBQUVBLFVBQUksQ0FBQ3BDLE1BQUwsRUFBYTtBQUNULGNBQU0sSUFBSU8sTUFBTSxDQUFDVyxLQUFYLENBQWlCLDZCQUFqQixFQUNOLGdDQURNLENBQU47QUFFSDs7QUFFRCxVQUFJbEIsTUFBTSxDQUFDa0QsSUFBUCxJQUFlLEtBQUs3QixNQUF4QixFQUFnQztBQUM5QixjQUFNLElBQUlkLE1BQU0sQ0FBQ1csS0FBWCxDQUFpQix5QkFBakIsRUFDSiwyQ0FESSxDQUFOO0FBRUQ7O0FBRUQ2QixvQkFBYyxDQUFDRixNQUFmLENBQXNCO0FBQ2xCN0MsY0FBTSxFQUFFb0MsUUFEVTtBQUVsQmdCLGFBRmtCO0FBR2xCQyxjQUhrQjtBQUlsQmQ7QUFKa0IsT0FBdEI7QUFPRCxLQW5Dc0I7O0FBcUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBZixRQUFJLENBQUNiLElBQUQsRUFBT2MsUUFBUCxFQUFpQjtBQUNuQixZQUFNQyxPQUFPLEdBQUc7QUFDZEMsdUJBQWUsRUFBRSxJQURIO0FBQ2E7QUFDM0JDLDJCQUFtQixFQUFFLElBRlAsQ0FFYTs7QUFGYixPQUFoQjtBQUtBckIsWUFBTSxDQUFDc0IsS0FBUCxDQUFhLEtBQUtwQixJQUFsQixFQUF3QixDQUFDRSxJQUFELENBQXhCLEVBQWdDZSxPQUFoQyxFQUF5Q0QsUUFBekM7QUFDRDs7QUFoRHNCLEdBQWxCOzs7Ozs7Ozs7Ozs7QUNKUHpCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNxRCxlQUFhLEVBQUMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJbkQsWUFBSjtBQUFpQkgsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSCxnQkFBWSxHQUFDRyxDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUlDLE1BQUo7QUFBV1AsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRyxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUUsa0JBQUo7QUFBdUJSLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ0ksb0JBQWtCLENBQUNGLENBQUQsRUFBRztBQUFDRSxzQkFBa0IsR0FBQ0YsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQXpCLEVBQXVFLENBQXZFO0FBQTBFLElBQUk0QixLQUFKO0FBQVVsQyxNQUFNLENBQUNJLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDOEIsT0FBSyxDQUFDNUIsQ0FBRCxFQUFHO0FBQUM0QixTQUFLLEdBQUM1QixDQUFOO0FBQVE7O0FBQWxCLENBQXBDLEVBQXdELENBQXhEO0FBS2pTLE1BQU1nRCxhQUFhLEdBQUc7QUFDekI3QyxNQUFJLEVBQUUsZ0JBRG1COztBQUd6QjtBQUNBQyxVQUFRLENBQUNDLElBQUQsRUFBTztBQUNYLFFBQUlSLFlBQUosQ0FBaUI7QUFDYk0sVUFBSSxFQUFFO0FBQUVJLFlBQUksRUFBRUM7QUFBUixPQURPO0FBRWJ5QyxXQUFLLEVBQUU7QUFBRTFDLFlBQUksRUFBRUM7QUFBUixPQUZNO0FBR2IwQyxpQkFBVyxFQUFFO0FBQUUzQyxZQUFJLEVBQUVDO0FBQVIsT0FIQTtBQUliMkMsY0FBUSxFQUFFO0FBQUU1QyxZQUFJLEVBQUVDO0FBQVIsT0FKRztBQUtieUIsZUFBUyxFQUFFO0FBQUUxQixZQUFJLEVBQUVvQztBQUFSO0FBTEUsS0FBakIsRUFNR3ZDLFFBTkgsQ0FNWUMsSUFOWjtBQU9ILEdBWndCOztBQWN6QjtBQUNBSSxLQUFHLE9BQW9EO0FBQUEsUUFBbkQ7QUFBRU4sVUFBRjtBQUFROEMsV0FBUjtBQUFlQyxpQkFBZjtBQUE0QkMsY0FBNUI7QUFBc0NsQjtBQUF0QyxLQUFtRDs7QUFFbkQsUUFBSSxDQUFDTCxLQUFLLENBQUNPLFlBQU4sQ0FBbUIsS0FBS3BCLE1BQXhCLEVBQWdDLFlBQWhDLENBQUwsRUFBb0Q7QUFDaEQsWUFBTSxJQUFJZCxNQUFNLENBQUNXLEtBQVgsQ0FBaUIsNkJBQWpCLEVBQ0YscURBREUsQ0FBTjtBQUVIOztBQUVELFFBQUlWLGtCQUFrQixDQUFDa0QsSUFBbkIsQ0FBd0I7QUFBRWpEO0FBQUYsS0FBeEIsRUFBa0NrRCxLQUFsQyxHQUEwQ0MsTUFBMUMsR0FBbUQsQ0FBdkQsRUFBMEQ7QUFDdEQsWUFBTSxJQUFJckQsTUFBTSxDQUFDVyxLQUFYLENBQWlCLDBCQUFqQixFQUNGLDRCQURFLENBQU47QUFFSDs7QUFFRFYsc0JBQWtCLENBQUNxQyxNQUFuQixDQUEwQjtBQUN0QnBDLFVBQUksRUFBRUEsSUFEZ0I7QUFFdEJvRCxrQkFBWSxFQUFFO0FBQ1ZOLGFBRFU7QUFFVkM7QUFGVSxPQUZRO0FBTXRCQyxjQU5zQjtBQU90QnRDLFdBQUssRUFBRSxFQVBlO0FBUXRCb0I7QUFSc0IsS0FBMUI7QUFXSCxHQXRDd0I7O0FBd0N6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBZixNQUFJLENBQUNiLElBQUQsRUFBT2MsUUFBUCxFQUFpQjtBQUNqQixVQUFNQyxPQUFPLEdBQUc7QUFDWkMscUJBQWUsRUFBRSxJQURMO0FBQ2U7QUFDM0JDLHlCQUFtQixFQUFFLElBRlQsQ0FFZTs7QUFGZixLQUFoQjtBQUtBckIsVUFBTSxDQUFDc0IsS0FBUCxDQUFhLEtBQUtwQixJQUFsQixFQUF3QixDQUFDRSxJQUFELENBQXhCLEVBQWdDZSxPQUFoQyxFQUF5Q0QsUUFBekM7QUFDSDs7QUFuRHdCLENBQXRCLEM7Ozs7Ozs7Ozs7O0FDTFB6QixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDNkQsZ0JBQWMsRUFBQyxNQUFJQTtBQUFwQixDQUFkO0FBQW1ELElBQUkzRCxZQUFKO0FBQWlCSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNILGdCQUFZLEdBQUNHLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSUMsTUFBSjtBQUFXUCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNHLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUQsbUJBQUosRUFBd0J2RCxrQkFBeEI7QUFBMkNSLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQzJELHFCQUFtQixDQUFDekQsQ0FBRCxFQUFHO0FBQUN5RCx1QkFBbUIsR0FBQ3pELENBQXBCO0FBQXNCLEdBQTlDOztBQUErQ0Usb0JBQWtCLENBQUNGLENBQUQsRUFBRztBQUFDRSxzQkFBa0IsR0FBQ0YsQ0FBbkI7QUFBcUI7O0FBQTFGLENBQXpCLEVBQXFILENBQXJIO0FBQXdILElBQUk0QixLQUFKO0FBQVVsQyxNQUFNLENBQUNJLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDOEIsT0FBSyxDQUFDNUIsQ0FBRCxFQUFHO0FBQUM0QixTQUFLLEdBQUM1QixDQUFOO0FBQVE7O0FBQWxCLENBQXBDLEVBQXdELENBQXhEO0FBS3JXLE1BQU13RCxjQUFjLEdBQUc7QUFDNUJyRCxNQUFJLEVBQUUsa0JBRHNCOztBQUc1QjtBQUNBQyxVQUFRLENBQUNDLElBQUQsRUFBTztBQUNiLFFBQUlSLFlBQUosQ0FBaUI7QUFDZjZDLFVBQUksRUFBRTtBQUFFbkMsWUFBSSxFQUFFQztBQUFSLE9BRFM7QUFFZkYsYUFBTyxFQUFFO0FBQUVDLFlBQUksRUFBRUM7QUFBUixPQUZNO0FBR2ZvQyxVQUFJLEVBQUU7QUFBRXJDLFlBQUksRUFBRUM7QUFBUixPQUhTO0FBSWZ5QixlQUFTLEVBQUU7QUFBRTFCLFlBQUksRUFBRW9DO0FBQVI7QUFKSSxLQUFqQixFQUtHdkMsUUFMSCxDQUtZQyxJQUxaO0FBTUQsR0FYMkI7O0FBYTVCO0FBQ0FJLEtBQUcsT0FBcUM7QUFBQSxRQUFwQztBQUFFaUMsVUFBRjtBQUFRcEMsYUFBUjtBQUFpQnNDLFVBQWpCO0FBQXVCWDtBQUF2QixLQUFvQzs7QUFFdEMsUUFBSS9CLGtCQUFrQixDQUFDa0QsSUFBbkIsQ0FBd0I7QUFBRWpELFVBQUksRUFBRUc7QUFBUixLQUF4QixFQUEyQytDLEtBQTNDLEdBQW1EQyxNQUFuRCxJQUE2RCxDQUFqRSxFQUFvRTtBQUNoRSxZQUFNLElBQUlyRCxNQUFNLENBQUNXLEtBQVgsQ0FBaUIsb0NBQWpCLEVBQ04saUNBRE0sQ0FBTjtBQUVIOztBQUVELFFBQUlnQyxJQUFJLElBQUksS0FBSzdCLE1BQWIsSUFBdUIsQ0FBQ2EsS0FBSyxDQUFDTyxZQUFOLENBQW1CLEtBQUtwQixNQUF4QixFQUFnQyxZQUFoQyxDQUE1QixFQUEyRTtBQUN6RSxZQUFNLElBQUlkLE1BQU0sQ0FBQ1csS0FBWCxDQUFpQix5QkFBakIsRUFDSixtRUFESSxDQUFOO0FBRUQ7O0FBRUQ2Qyx1QkFBbUIsQ0FBQ2xCLE1BQXBCLENBQTJCO0FBQ3ZCRyxVQUR1QjtBQUV2QnBDLGFBRnVCO0FBR3ZCc0MsVUFIdUI7QUFJdkJYO0FBSnVCLEtBQTNCO0FBT0QsR0FqQzJCOztBQW1DNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQWYsTUFBSSxDQUFDYixJQUFELEVBQU9jLFFBQVAsRUFBaUI7QUFDbkIsVUFBTUMsT0FBTyxHQUFHO0FBQ2RDLHFCQUFlLEVBQUUsSUFESDtBQUNhO0FBQzNCQyx5QkFBbUIsRUFBRSxJQUZQLENBRWE7O0FBRmIsS0FBaEI7QUFLQXJCLFVBQU0sQ0FBQ3NCLEtBQVAsQ0FBYSxLQUFLcEIsSUFBbEIsRUFBd0IsQ0FBQ0UsSUFBRCxDQUF4QixFQUFnQ2UsT0FBaEMsRUFBeUNELFFBQXpDO0FBQ0Q7O0FBOUMyQixDQUF2QixDOzs7Ozs7Ozs7Ozs7QUNMUEssU0FBTyxDQUFDN0IsTUFBUixDQUFlO0FBQUMrRCxnQkFBWSxFQUFDLE1BQUlBO0FBQWxCLEdBQWY7QUFBZ0QsTUFBSTdELFlBQUo7QUFBaUIyQixTQUFPLENBQUMxQixJQUFSLENBQWEsY0FBYixFQUE0QjtBQUFDQyxXQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSCxrQkFBWSxHQUFDRyxDQUFiO0FBQWU7O0FBQTNCLEdBQTVCLEVBQXlELENBQXpEO0FBQTRELE1BQUlDLE1BQUo7QUFBV3VCLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxlQUFiLEVBQTZCO0FBQUNHLFVBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFlBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixHQUE3QixFQUFtRCxDQUFuRDtBQUFzRCxNQUFJMEIsa0JBQUosRUFBdUJDLGlCQUF2QjtBQUF5Q0gsU0FBTyxDQUFDMUIsSUFBUixDQUFhLFlBQWIsRUFBMEI7QUFBQzRCLHNCQUFrQixDQUFDMUIsQ0FBRCxFQUFHO0FBQUMwQix3QkFBa0IsR0FBQzFCLENBQW5CO0FBQXFCLEtBQTVDOztBQUE2QzJCLHFCQUFpQixDQUFDM0IsQ0FBRCxFQUFHO0FBQUMyQix1QkFBaUIsR0FBQzNCLENBQWxCO0FBQW9COztBQUF0RixHQUExQixFQUFrSCxDQUFsSDtBQUloTyxRQUFNMEQsWUFBWSxHQUFHO0FBQzFCdkQsUUFBSSxFQUFFLGVBRG9COztBQUcxQjtBQUNBQyxZQUFRLENBQUNDLElBQUQsRUFBTztBQUNiLFVBQUlSLFlBQUosQ0FBaUI7QUFDZjhELGtCQUFVLEVBQUU7QUFBRXBELGNBQUksRUFBRUM7QUFBUixTQURHO0FBRWZvRCxjQUFNLEVBQUU7QUFBRXJELGNBQUksRUFBRXNEO0FBQVIsU0FGTztBQUdmNUIsaUJBQVMsRUFBRTtBQUFFMUIsY0FBSSxFQUFFb0M7QUFBUjtBQUhJLE9BQWpCLEVBSUd2QyxRQUpILENBSVlDLElBSlo7QUFLRCxLQVZ5Qjs7QUFZMUI7QUFDQUksT0FBRyxPQUFvQztBQUFBLFVBQW5DO0FBQUVrRCxrQkFBRjtBQUFjQyxjQUFkO0FBQXNCM0I7QUFBdEIsT0FBbUM7QUFFckMsWUFBTTZCLFFBQVEsR0FBR3BDLGtCQUFrQixDQUFDZixPQUFuQixDQUEyQjtBQUFFdUIsV0FBRyxFQUFFeUI7QUFBUCxPQUEzQixDQUFqQjtBQUNBLFlBQU03QixRQUFRLEdBQUdnQyxRQUFRLENBQUNwRSxNQUExQjtBQUVBLFlBQU1BLE1BQU0sR0FBR2lDLGlCQUFpQixDQUFDaEIsT0FBbEIsQ0FBMEI7QUFBRXVCLFdBQUcsRUFBRUo7QUFBUCxPQUExQixDQUFmO0FBQ0EsWUFBTWlDLEtBQUssR0FBR3JFLE1BQU0sQ0FBQ2tELElBQXJCOztBQUVBLFVBQUltQixLQUFLLElBQUksS0FBS2hELE1BQWxCLEVBQTBCO0FBQ3hCLGNBQU0sSUFBSWQsTUFBTSxDQUFDVyxLQUFYLENBQWlCLDRCQUFqQixFQUNKLDZEQURJLENBQU47QUFFRDs7QUFFRGMsd0JBQWtCLENBQUNWLE1BQW5CLENBQTBCO0FBQUVrQixXQUFHLEVBQUV5QjtBQUFQLE9BQTFCLEVBQStDO0FBQzdDSyxZQUFJLEVBQUU7QUFDSkMsaUJBQU8sRUFBRUwsTUFETDtBQUVKTSxpQkFBTyxFQUFFakM7QUFGTDtBQUR1QyxPQUEvQztBQU9ELEtBakN5Qjs7QUFtQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0FmLFFBQUksQ0FBQ2IsSUFBRCxFQUFPYyxRQUFQLEVBQWlCO0FBQ25CLFlBQU1DLE9BQU8sR0FBRztBQUNkQyx1QkFBZSxFQUFFLElBREg7QUFDYTtBQUMzQkMsMkJBQW1CLEVBQUUsSUFGUCxDQUVhOztBQUZiLE9BQWhCO0FBS0FyQixZQUFNLENBQUNzQixLQUFQLENBQWEsS0FBS3BCLElBQWxCLEVBQXdCLENBQUNFLElBQUQsQ0FBeEIsRUFBZ0NlLE9BQWhDLEVBQXlDRCxRQUF6QztBQUNEOztBQTlDeUIsR0FBckI7Ozs7Ozs7Ozs7Ozs7QUNKUEssU0FBTyxDQUFDN0IsTUFBUixDQUFlO0FBQUN3RSxnQkFBWSxFQUFDLE1BQUlBO0FBQWxCLEdBQWY7QUFBZ0QsTUFBSXRFLFlBQUo7QUFBaUIyQixTQUFPLENBQUMxQixJQUFSLENBQWEsY0FBYixFQUE0QjtBQUFDQyxXQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSCxrQkFBWSxHQUFDRyxDQUFiO0FBQWU7O0FBQTNCLEdBQTVCLEVBQXlELENBQXpEO0FBQTRELE1BQUlDLE1BQUo7QUFBV3VCLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxlQUFiLEVBQTZCO0FBQUNHLFVBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFlBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixHQUE3QixFQUFtRCxDQUFuRDtBQUFzRCxNQUFJMkIsaUJBQUo7QUFBc0JILFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxZQUFiLEVBQTBCO0FBQUM2QixxQkFBaUIsQ0FBQzNCLENBQUQsRUFBRztBQUFDMkIsdUJBQWlCLEdBQUMzQixDQUFsQjtBQUFvQjs7QUFBMUMsR0FBMUIsRUFBc0UsQ0FBdEU7QUFLN00sUUFBTW1FLFlBQVksR0FBRztBQUMxQmhFLFFBQUksRUFBRSxnQkFEb0I7O0FBRzFCO0FBQ0FDLFlBQVEsQ0FBQ0MsSUFBRCxFQUFPO0FBQ2IsVUFBSVIsWUFBSixDQUFpQjtBQUNmaUMsZ0JBQVEsRUFBRTtBQUFFdkIsY0FBSSxFQUFFQztBQUFSLFNBREs7QUFFZmtDLFlBQUksRUFBRTtBQUFFbkMsY0FBSSxFQUFFQztBQUFSLFNBRlM7QUFHZnlCLGlCQUFTLEVBQUU7QUFBRTFCLGNBQUksRUFBRW9DO0FBQVI7QUFISSxPQUFqQixFQUlHdkMsUUFKSCxDQUlZQyxJQUpaO0FBS0QsS0FWeUI7O0FBWTFCO0FBQ0FJLE9BQUcsT0FBZ0M7QUFBQSxVQUEvQjtBQUFFcUIsZ0JBQUY7QUFBWVksWUFBWjtBQUFrQlQ7QUFBbEIsT0FBK0I7QUFFakMsWUFBTXZDLE1BQU0sR0FBR2lDLGlCQUFpQixDQUFDaEIsT0FBbEIsQ0FBMEI7QUFBRXVCLFdBQUcsRUFBRUo7QUFBUCxPQUExQixDQUFmOztBQUVBLFVBQUlwQyxNQUFNLENBQUNrRCxJQUFQLElBQWUsS0FBSzdCLE1BQXhCLEVBQWdDO0FBQzlCLGNBQU0sSUFBSWQsTUFBTSxDQUFDVyxLQUFYLENBQWlCLDZCQUFqQixFQUNKLHNDQURJLENBQU47QUFFRDs7QUFFRGUsdUJBQWlCLENBQUNYLE1BQWxCLENBQXlCO0FBQUVrQixXQUFHLEVBQUVKO0FBQVAsT0FBekIsRUFBNEM7QUFDMUNrQyxZQUFJLEVBQUU7QUFDSnRCLGNBREk7QUFFSlQ7QUFGSTtBQURvQyxPQUE1QztBQU9ELEtBN0J5Qjs7QUErQjFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0FmLFFBQUksQ0FBQ2IsSUFBRCxFQUFPYyxRQUFQLEVBQWlCO0FBQ25CLFlBQU1DLE9BQU8sR0FBRztBQUNkQyx1QkFBZSxFQUFFLElBREg7QUFDYTtBQUMzQkMsMkJBQW1CLEVBQUUsSUFGUCxDQUVhOztBQUZiLE9BQWhCO0FBS0FyQixZQUFNLENBQUNzQixLQUFQLENBQWEsS0FBS3BCLElBQWxCLEVBQXdCLENBQUNFLElBQUQsQ0FBeEIsRUFBZ0NlLE9BQWhDLEVBQXlDRCxRQUF6QztBQUNEOztBQTFDeUIsR0FBckI7Ozs7Ozs7Ozs7OztBQ0xQekIsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ08sb0JBQWtCLEVBQUMsTUFBSUEsa0JBQXhCO0FBQTJDdUQscUJBQW1CLEVBQUMsTUFBSUEsbUJBQW5FO0FBQXVGOUIsbUJBQWlCLEVBQUMsTUFBSUEsaUJBQTdHO0FBQStIYyxnQkFBYyxFQUFDLE1BQUlBLGNBQWxKO0FBQWlLZixvQkFBa0IsRUFBQyxNQUFJQTtBQUF4TCxDQUFkO0FBQTJOLElBQUkwQyxLQUFKO0FBQVUxRSxNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNzRSxPQUFLLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLFNBQUssR0FBQ3BFLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFOU4sTUFBTUUsa0JBQWtCLEdBQUcsSUFBSWtFLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixVQUFyQixDQUEzQjtBQUNBLE1BQU1aLG1CQUFtQixHQUFHLElBQUlXLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUE1QjtBQUNBLE1BQU0xQyxpQkFBaUIsR0FBRyxJQUFJeUMsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFNBQXJCLENBQTFCO0FBQ0EsTUFBTTVCLGNBQWMsR0FBRyxJQUFJMkIsS0FBSyxDQUFDQyxVQUFWLENBQXFCLE1BQXJCLENBQXZCO0FBQ0EsTUFBTTNDLGtCQUFrQixHQUFHLElBQUkwQyxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsVUFBckIsQ0FBM0IsQzs7Ozs7Ozs7Ozs7O0FDTlA3QyxTQUFPLENBQUM3QixNQUFSLENBQWU7QUFBQzJFLGNBQVUsRUFBQyxNQUFJQTtBQUFoQixHQUFmO0FBQTRDLE1BQUlyRSxNQUFKO0FBQVd1QixTQUFPLENBQUMxQixJQUFSLENBQWEsZUFBYixFQUE2QjtBQUFDRyxVQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxZQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsR0FBN0IsRUFBbUQsQ0FBbkQ7QUFBc0QsTUFBSXVFLFFBQUo7QUFBYS9DLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxzQkFBYixFQUFvQztBQUFDeUUsWUFBUSxDQUFDdkUsQ0FBRCxFQUFHO0FBQUN1RSxjQUFRLEdBQUN2RSxDQUFUO0FBQVc7O0FBQXhCLEdBQXBDLEVBQThELENBQTlEO0FBQWlFLE1BQUl5QyxjQUFKLEVBQW1CZCxpQkFBbkIsRUFBcUM4QixtQkFBckMsRUFBeUQvQixrQkFBekQsRUFBNEV4QixrQkFBNUU7QUFBK0ZzQixTQUFPLENBQUMxQixJQUFSLENBQWEsd0JBQWIsRUFBc0M7QUFBQzJDLGtCQUFjLENBQUN6QyxDQUFELEVBQUc7QUFBQ3lDLG9CQUFjLEdBQUN6QyxDQUFmO0FBQWlCLEtBQXBDOztBQUFxQzJCLHFCQUFpQixDQUFDM0IsQ0FBRCxFQUFHO0FBQUMyQix1QkFBaUIsR0FBQzNCLENBQWxCO0FBQW9CLEtBQTlFOztBQUErRXlELHVCQUFtQixDQUFDekQsQ0FBRCxFQUFHO0FBQUN5RCx5QkFBbUIsR0FBQ3pELENBQXBCO0FBQXNCLEtBQTVIOztBQUE2SDBCLHNCQUFrQixDQUFDMUIsQ0FBRCxFQUFHO0FBQUMwQix3QkFBa0IsR0FBQzFCLENBQW5CO0FBQXFCLEtBQXhLOztBQUF5S0Usc0JBQWtCLENBQUNGLENBQUQsRUFBRztBQUFDRSx3QkFBa0IsR0FBQ0YsQ0FBbkI7QUFBcUI7O0FBQXBOLEdBQXRDLEVBQTRQLENBQTVQO0FBQStQLE1BQUk0QixLQUFKO0FBQVVKLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSx1QkFBYixFQUFxQztBQUFDOEIsU0FBSyxDQUFDNUIsQ0FBRCxFQUFHO0FBQUM0QixXQUFLLEdBQUM1QixDQUFOO0FBQVE7O0FBQWxCLEdBQXJDLEVBQXlELENBQXpEO0FBQTRELE1BQUl5QixjQUFKO0FBQW1CRCxTQUFPLENBQUMxQixJQUFSLENBQWEsdUNBQWIsRUFBcUQ7QUFBQzJCLGtCQUFjLENBQUN6QixDQUFELEVBQUc7QUFBQ3lCLG9CQUFjLEdBQUN6QixDQUFmO0FBQWlCOztBQUFwQyxHQUFyRCxFQUEyRixDQUEzRjtBQUE4RixNQUFJd0MsWUFBSjtBQUFpQmhCLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxxQ0FBYixFQUFtRDtBQUFDMEMsZ0JBQVksQ0FBQ3hDLENBQUQsRUFBRztBQUFDd0Msa0JBQVksR0FBQ3hDLENBQWI7QUFBZTs7QUFBaEMsR0FBbkQsRUFBcUYsQ0FBckY7QUFBd0YsTUFBSTZDLFNBQUo7QUFBY3JCLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxrQ0FBYixFQUFnRDtBQUFDK0MsYUFBUyxDQUFDN0MsQ0FBRCxFQUFHO0FBQUM2QyxlQUFTLEdBQUM3QyxDQUFWO0FBQVk7O0FBQTFCLEdBQWhELEVBQTRFLENBQTVFO0FBQStFLE1BQUlnRCxhQUFKO0FBQWtCeEIsU0FBTyxDQUFDMUIsSUFBUixDQUFhLHNDQUFiLEVBQW9EO0FBQUNrRCxpQkFBYSxDQUFDaEQsQ0FBRCxFQUFHO0FBQUNnRCxtQkFBYSxHQUFDaEQsQ0FBZDtBQUFnQjs7QUFBbEMsR0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsTUFBSXdELGNBQUo7QUFBbUJoQyxTQUFPLENBQUMxQixJQUFSLENBQWEsdUNBQWIsRUFBcUQ7QUFBQzBELGtCQUFjLENBQUN4RCxDQUFELEVBQUc7QUFBQ3dELG9CQUFjLEdBQUN4RCxDQUFmO0FBQWlCOztBQUFwQyxHQUFyRCxFQUEyRixDQUEzRjtBQUE4RixNQUFJMEQsWUFBSjtBQUFpQmxDLFNBQU8sQ0FBQzFCLElBQVIsQ0FBYSxxQ0FBYixFQUFtRDtBQUFDNEQsZ0JBQVksQ0FBQzFELENBQUQsRUFBRztBQUFDMEQsa0JBQVksR0FBQzFELENBQWI7QUFBZTs7QUFBaEMsR0FBbkQsRUFBcUYsQ0FBckY7QUFBd0YsTUFBSW1FLFlBQUo7QUFBaUIzQyxTQUFPLENBQUMxQixJQUFSLENBQWEscUNBQWIsRUFBbUQ7QUFBQ3FFLGdCQUFZLENBQUNuRSxDQUFELEVBQUc7QUFBQ21FLGtCQUFZLEdBQUNuRSxDQUFiO0FBQWU7O0FBQWhDLEdBQW5ELEVBQXFGLEVBQXJGO0FBQXlGLE1BQUlKLGNBQUo7QUFBbUI0QixTQUFPLENBQUMxQixJQUFSLENBQWEsdUNBQWIsRUFBcUQ7QUFBQ0Ysa0JBQWMsQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNKLG9CQUFjLEdBQUNJLENBQWY7QUFBaUI7O0FBQXBDLEdBQXJELEVBQTJGLEVBQTNGO0FBZ0JuMUMsUUFBTXNFLFVBQVUsR0FBRyxZQUFuQjtBQUNQLFFBQU1FLFFBQVEsR0FBRyxFQUFqQjtBQUVBdkUsUUFBTSxDQUFDd0UsT0FBUCxDQUFlLE1BQU07QUFDbkI7QUFDQSxLQUFDLEdBQUdELFFBQUosRUFBY0YsVUFBZCxFQUEwQkksT0FBMUIsQ0FBbUN2RSxJQUFELElBQVU7QUFDMUMsVUFBSSxDQUFDb0UsUUFBUSxDQUFDSSxrQkFBVCxDQUE0QnhFLElBQTVCLENBQUwsRUFBd0M7QUFDdENvRSxnQkFBUSxDQUFDSyxVQUFULENBQW9CO0FBQ2xCQyxrQkFBUSxFQUFFMUUsSUFEUTtBQUVsQjJFLGtCQUFRLEVBQUU7QUFGUSxTQUFwQjtBQUlEO0FBQ0YsS0FQRCxFQUZtQixDQVduQjs7QUFDQSxRQUFJLENBQUM3RSxNQUFNLENBQUM4RSxLQUFQLENBQWFwRSxPQUFiLENBQXFCO0FBQUV1QixTQUFHLEVBQUU7QUFBUCxLQUFyQixDQUFMLEVBQStDO0FBQzdDTixXQUFLLENBQUNvRCxVQUFOLENBQWlCLFNBQWpCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDL0UsTUFBTSxDQUFDOEUsS0FBUCxDQUFhcEUsT0FBYixDQUFxQjtBQUFFdUIsU0FBRyxFQUFFO0FBQVAsS0FBckIsQ0FBTCxFQUFrRDtBQUNoRE4sV0FBSyxDQUFDb0QsVUFBTixDQUFpQixZQUFqQjtBQUNELEtBbEJrQixDQW9CbkI7OztBQUNBLFVBQU1DLFlBQVksR0FBR2hGLE1BQU0sQ0FBQ1ksS0FBUCxDQUFhRixPQUFiLENBQXFCO0FBQUVrRSxjQUFRLEVBQUU7QUFBWixLQUFyQixFQUFpRDNDLEdBQXRFOztBQUNBTixTQUFLLENBQUNzRCxlQUFOLENBQXNCRCxZQUF0QixFQUFvQyxZQUFwQyxFQXRCbUIsQ0F3Qm5CO0FBQ0E7O0FBQ0F0RCxxQkFBaUIsQ0FBQ3dELElBQWxCLENBQXVCO0FBQ3JCNUMsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWMsT0FESjs7QUFFckJ2QixZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQUZKOztBQUdyQm9FLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjOztBQUhKLEtBQXZCO0FBTUFsRixzQkFBa0IsQ0FBQ2lGLElBQW5CLENBQXdCO0FBQ3RCNUMsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWMsT0FESDs7QUFFdEJ2QixZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQUZIOztBQUd0Qm9FLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjOztBQUhILEtBQXhCO0FBTUEzQix1QkFBbUIsQ0FBQzBCLElBQXBCLENBQXlCO0FBQ3ZCNUMsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWMsT0FERjs7QUFFdkJ2QixZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQUZGOztBQUd2Qm9FLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjOztBQUhGLEtBQXpCO0FBTUExRCxzQkFBa0IsQ0FBQ3lELElBQW5CLENBQXdCO0FBQ3RCNUMsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWMsT0FESDs7QUFFdEJ2QixZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQUZIOztBQUd0Qm9FLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjOztBQUhILEtBQXhCO0FBTUEzQyxrQkFBYyxDQUFDMEMsSUFBZixDQUFvQjtBQUNsQjVDLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjLE9BRFA7O0FBRWxCdkIsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWMsT0FGUDs7QUFHbEJvRSxZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYzs7QUFIUCxLQUFwQjtBQU1BbkYsVUFBTSxDQUFDb0YsT0FBUCxDQUFlLFVBQWYsRUFBMkIsWUFBWTtBQUNyQyxhQUFPcEYsTUFBTSxDQUFDWSxLQUFQLENBQWF1QyxJQUFiLENBQWtCLEVBQWxCLEVBQXNCO0FBQzNCa0MsY0FBTSxFQUFFO0FBQUVULGtCQUFRLEVBQUUsQ0FBWjtBQUFlNUMsbUJBQVMsRUFBRSxDQUExQjtBQUE2QkMsYUFBRyxFQUFFO0FBQWxDO0FBRG1CLE9BQXRCLENBQVA7QUFHRCxLQUpEO0FBTUFqQyxVQUFNLENBQUNvRixPQUFQLENBQWUsVUFBZixFQUEyQixZQUFZO0FBQ3JDLGFBQU9uRixrQkFBa0IsQ0FBQ2tELElBQW5CLEVBQVA7QUFDRCxLQUZEO0FBSUFuRCxVQUFNLENBQUNvRixPQUFQLENBQWUsU0FBZixFQUEwQixZQUFZO0FBQ3BDLFlBQU1FLE1BQU0sR0FBRyxLQUFLeEUsTUFBcEIsQ0FEb0MsQ0FFcEM7O0FBQ0EsYUFBT1ksaUJBQWlCLENBQUN5QixJQUFsQixDQUF1QnhCLEtBQUssQ0FBQ08sWUFBTixDQUFtQixLQUFLcEIsTUFBeEIsRUFBZ0MsWUFBaEMsSUFBZ0QsRUFBaEQsR0FBcUQ7QUFBRTZCLFlBQUksRUFBRTJDO0FBQVIsT0FBNUUsQ0FBUDtBQUNELEtBSkQ7QUFNQXRGLFVBQU0sQ0FBQ29GLE9BQVAsQ0FBZSxNQUFmLEVBQXVCLFlBQVk7QUFDakMsWUFBTUUsTUFBTSxHQUFHLEtBQUt4RSxNQUFwQixDQURpQyxDQUdqQzs7QUFDQSxZQUFNeUUsT0FBTyxHQUFHN0QsaUJBQWlCLENBQUN5QixJQUFsQixDQUF1QnhCLEtBQUssQ0FBQ08sWUFBTixDQUFtQixLQUFLcEIsTUFBeEIsRUFBZ0MsWUFBaEMsSUFBZ0QsRUFBaEQsR0FBcUQ7QUFBRTZCLFlBQUksRUFBRTJDO0FBQVIsT0FBNUUsRUFBOEZsQyxLQUE5RixFQUFoQjtBQUNBLGFBQU9aLGNBQWMsQ0FBQ1csSUFBZixDQUFvQjtBQUFFMUQsY0FBTSxFQUFFO0FBQUUrRixhQUFHLEVBQUVELE9BQU8sQ0FBQ0UsR0FBUixDQUFZaEcsTUFBTSxJQUFJQSxNQUFNLENBQUN3QyxHQUE3QjtBQUFQO0FBQVYsT0FBcEIsQ0FBUDtBQUNELEtBTkQ7QUFRQWpDLFVBQU0sQ0FBQ29GLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFlBQVk7QUFDdEMsWUFBTUUsTUFBTSxHQUFHLEtBQUt4RSxNQUFwQixDQURzQyxDQUV0Qzs7QUFDQSxhQUFPMEMsbUJBQW1CLENBQUNMLElBQXBCLENBQXlCeEIsS0FBSyxDQUFDTyxZQUFOLENBQW1CLEtBQUtwQixNQUF4QixFQUFnQyxZQUFoQyxJQUFnRCxFQUFoRCxHQUFxRDtBQUFFNkIsWUFBSSxFQUFFMkM7QUFBUixPQUE5RSxDQUFQO0FBQ0QsS0FKRDtBQU1BdEYsVUFBTSxDQUFDb0YsT0FBUCxDQUFlLFVBQWYsRUFBMkIsWUFBWTtBQUNyQyxZQUFNRSxNQUFNLEdBQUcsS0FBS3hFLE1BQXBCO0FBQ0EsWUFBTTRFLGNBQWMsR0FBR2hFLGlCQUFpQixDQUFDeUIsSUFBbEIsQ0FBdUI7QUFBRVIsWUFBSSxFQUFFMkM7QUFBUixPQUF2QixFQUF5Q2xDLEtBQXpDLEVBQXZCO0FBQ0EsYUFBTzNCLGtCQUFrQixDQUFDMEIsSUFBbkIsQ0FBd0J4QixLQUFLLENBQUNPLFlBQU4sQ0FBbUIsS0FBS3BCLE1BQXhCLEVBQWdDLFlBQWhDLElBQWdELEVBQWhELEdBQXFEO0FBQUVyQixjQUFNLEVBQUU7QUFBRStGLGFBQUcsRUFBRUUsY0FBYyxDQUFDRCxHQUFmLENBQW1CRSxDQUFDLElBQUlBLENBQUMsQ0FBQzFELEdBQTFCO0FBQVA7QUFBVixPQUE3RSxDQUFQO0FBQ0QsS0FKRCxFQXRGbUIsQ0E0Rm5COztBQUNBLFVBQU0yRCxPQUFPLEdBQUcsQ0FBQ3BFLGNBQUQsRUFBaUJlLFlBQWpCLEVBQStCSyxTQUEvQixFQUEwQ0csYUFBMUMsRUFBeURRLGNBQXpELEVBQXlFRSxZQUF6RSxFQUF1RlMsWUFBdkYsRUFBcUd2RSxjQUFyRyxDQUFoQjtBQUVBaUcsV0FBTyxDQUFDbkIsT0FBUixDQUFnQm9CLE1BQU0sSUFBSTtBQUN4QjtBQUNBN0YsWUFBTSxDQUFDNEYsT0FBUCxDQUFlO0FBQ2IsU0FBQ0MsTUFBTSxDQUFDM0YsSUFBUixHQUFlLFVBQVVFLElBQVYsRUFBZ0I7QUFDN0J5RixnQkFBTSxDQUFDMUYsUUFBUCxDQUFnQmMsSUFBaEIsQ0FBcUIsSUFBckIsRUFBMkJiLElBQTNCO0FBQ0F5RixnQkFBTSxDQUFDckYsR0FBUCxDQUFXUyxJQUFYLENBQWdCLElBQWhCLEVBQXNCYixJQUF0QjtBQUNEO0FBSlksT0FBZjtBQU1ELEtBUkQ7QUFVRCxHQXpHRCIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgU2Vzc2lvbnNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vbW9kdWxlcyc7XHJcblxyXG5cclxuZXhwb3J0IGNvbnN0IGFkZFNlc3Npb25Vc2VyID0ge1xyXG4gIG5hbWU6ICdzZXNzaW9uLmFkZHVzZXInLFxyXG5cclxuICAvLyBGYWN0b3Igb3V0IHZhbGlkYXRpb24gc28gdGhhdCBpdCBjYW4gYmUgcnVuIGluZGVwZW5kZW50bHkgKDEpXHJcbiAgdmFsaWRhdGUoYXJncykge1xyXG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XHJcbiAgICAgIHNlc3Npb246IHsgdHlwZTogU3RyaW5nIH0sXHJcbiAgICB9KS52YWxpZGF0ZShhcmdzKVxyXG4gIH0sXHJcblxyXG4gIC8vIEZhY3RvciBvdXQgTWV0aG9kIGJvZHkgc28gdGhhdCBpdCBjYW4gYmUgY2FsbGVkIGluZGVwZW5kZW50bHkgKDMpXHJcbiAgcnVuKHsgc2Vzc2lvbiB9KSB7XHJcblxyXG4gICAgY29uc3Qgc2Vzc2lvbkRhdGEgPSBTZXNzaW9uc0NvbGxlY3Rpb24uZmluZE9uZSh7IG5hbWU6IHNlc3Npb24gfSk7XHJcblxyXG4gICAgaWYgKCFzZXNzaW9uRGF0YSkge1xyXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3Nlc3Npb24uYWRkdXNlci5zZXNzaW9uX25vdF9mb3VuZCcsXHJcbiAgICAgICAgJ0Nhbm5vdCBnaXZlIGpvaW4gbm9uLWV4aXN0ZW50IHNlc3Npb24nKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoc2Vzc2lvbkRhdGEudXNlcnMuaW5jbHVkZXModGhpcy51c2VySWQpKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignc2Vzc2lvbi5hZGR1c2VyLmR1cGxpY2F0ZScsIFxyXG4gICAgICAgICdVc2VyIGFscmVhZHkgbWVtYmVyIG9mIHNlc3Npb24nKTtcclxuICAgIH1cclxuXHJcbiAgICBTZXNzaW9uc0NvbGxlY3Rpb24udXBkYXRlKHsgbmFtZTogc2Vzc2lvbiB9LCB7IFxyXG4gICAgICAgICRhZGRUb1NldDogeyB1c2VyczogdGhpcy51c2VySWQgfVxyXG4gICAgfSk7XHJcblxyXG4gIH0sXHJcblxyXG4gIC8vIENhbGwgTWV0aG9kIGJ5IHJlZmVyZW5jaW5nIHRoZSBKUyBvYmplY3QgKDQpXHJcbiAgLy8gQWxzbywgdGhpcyBsZXRzIHVzIHNwZWNpZnkgTWV0ZW9yLmFwcGx5IG9wdGlvbnMgb25jZSBpblxyXG4gIC8vIHRoZSBNZXRob2QgaW1wbGVtZW50YXRpb24sIHJhdGhlciB0aGFuIHJlcXVpcmluZyB0aGUgY2FsbGVyXHJcbiAgLy8gdG8gc3BlY2lmeSBpdCBhdCB0aGUgY2FsbCBzaXRlLlxyXG4gIGNhbGwoYXJncywgY2FsbGJhY2spIHtcclxuICAgIGNvbnN0IG9wdGlvbnMgPSB7XHJcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZSwgICAgIC8vICg1KVxyXG4gICAgICB0aHJvd1N0dWJFeGNlcHRpb25zOiB0cnVlICAvLyAoNilcclxuICAgIH1cclxuXHJcbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbYXJnc10sIG9wdGlvbnMsIGNhbGxiYWNrKTtcclxuICB9XHJcbn07XHJcblxyXG5cclxuIiwiaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgRmVlZGJhY2tDb2xsZWN0aW9uLCBNb2R1bGVzQ29sbGVjdGlvbiB9IGZyb20gJy4uL21vZHVsZXMnO1xyXG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XHJcblxyXG5leHBvcnQgY29uc3QgY3JlYXRlRmVlZGJhY2sgPSB7XHJcbiAgbmFtZTogJ2ZlZWRiYWNrLmNyZWF0ZScsXHJcblxyXG4gIC8vIEZhY3RvciBvdXQgdmFsaWRhdGlvbiBzbyB0aGF0IGl0IGNhbiBiZSBydW4gaW5kZXBlbmRlbnRseSAoMSlcclxuICB2YWxpZGF0ZShhcmdzKSB7XHJcbiAgICAvLyBUT0RPOiBmaXggc2NoZW1hIHRvIHZhbGlkYXRlIGhpZ2hsaWdodGVkIHJlZ2lvbnNcclxuICAgIC8vIG5ldyBTaW1wbGVTY2hlbWEoe1xyXG4gICAgLy8gICBtb2R1bGVJRDogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgIC8vICAgbWVzc2FnZTogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgIC8vICAgc25hcHNob3Q6IHsgdHlwZTogU3RyaW5nIH0sXHJcbiAgICAvLyAgIGNyZWF0ZWRBdDogeyB0eXBlOiBEYXRlIH0sXHJcbiAgICAvLyB9KS52YWxpZGF0ZShhcmdzKVxyXG4gIH0sXHJcblxyXG4gIC8vIEZhY3RvciBvdXQgTWV0aG9kIGJvZHkgc28gdGhhdCBpdCBjYW4gYmUgY2FsbGVkIGluZGVwZW5kZW50bHkgKDMpXHJcbiAgcnVuKHsgYm9keSwgbW9kdWxlSUQsIHNuYXBzaG90SUQsIHNlbGVjdGVkUmVnaW9ucywgY3JlYXRlZEF0IH0pIHtcclxuXHJcbiAgICBjb25zdCBtb2R1bGUgPSBNb2R1bGVzQ29sbGVjdGlvbi5maW5kT25lKHsgX2lkOiBtb2R1bGVJRCB9KTtcclxuICAgIFxyXG4gICAgaWYgKCFSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsICdpbnN0cnVjdG9yJykpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigncnVuLmNyZWF0ZS51bmF1dGhvcml6ZWQnLFxyXG4gICAgICAgICdDYW5ub3QgY3JlYXRlIGZlZWRiYWNrIHRoYXQgaXMgbm90IHlvdXJzJyk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFtb2R1bGUpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignZmVlZGJhY2suY3JlYXRlLm1vZHVsZV9ub3RfZm91bmQnLFxyXG4gICAgICAgICdDYW5ub3QgZ2l2ZSBmZWVkYmFjayB0byBub24tZXhpc3RlbnQgbW9kdWxlJyk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZGF0YSA9IHtcclxuICAgICAgYm9keTogYm9keSxcclxuICAgICAgbW9kdWxlOiBtb2R1bGVJRCwgLy8gVE9ETzogaXMgdGhpcyBuZWNlc3Nhcnkgd2hlbiBzbmFwc2hvdCBpcyBwcm92aWRlZD9cclxuICAgICAgc25hcHNob3Q6IHNuYXBzaG90SUQsXHJcbiAgICAgIHJlZ2lvbjogc2VsZWN0ZWRSZWdpb25zLFxyXG4gICAgICBjcmVhdGVkQXQsXHJcbiAgICB9O1xyXG5cclxuICAgIEZlZWRiYWNrQ29sbGVjdGlvbi5pbnNlcnQoZGF0YSlcclxuXHJcbiAgfSxcclxuXHJcbiAgLy8gQ2FsbCBNZXRob2QgYnkgcmVmZXJlbmNpbmcgdGhlIEpTIG9iamVjdCAoNClcclxuICAvLyBBbHNvLCB0aGlzIGxldHMgdXMgc3BlY2lmeSBNZXRlb3IuYXBwbHkgb3B0aW9ucyBvbmNlIGluXHJcbiAgLy8gdGhlIE1ldGhvZCBpbXBsZW1lbnRhdGlvbiwgcmF0aGVyIHRoYW4gcmVxdWlyaW5nIHRoZSBjYWxsZXJcclxuICAvLyB0byBzcGVjaWZ5IGl0IGF0IHRoZSBjYWxsIHNpdGUuXHJcbiAgY2FsbChhcmdzLCBjYWxsYmFjaykge1xyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlLCAgICAgLy8gKDUpXHJcbiAgICAgIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWUgIC8vICg2KVxyXG4gICAgfVxyXG5cclxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFthcmdzXSwgb3B0aW9ucywgY2FsbGJhY2spO1xyXG4gIH1cclxufTtcclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG4iLCJpbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBNb2R1bGVzQ29sbGVjdGlvbiwgUnVuc0NvbGxlY3Rpb24gfSBmcm9tICcuLi9tb2R1bGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCBjcmVhdGVNb2R1bGUgPSB7XHJcbiAgICBuYW1lOiAnbW9kdWxlcy5jcmVhdGUnLFxyXG5cclxuICAgIC8vIEZhY3RvciBvdXQgdmFsaWRhdGlvbiBzbyB0aGF0IGl0IGNhbiBiZSBydW4gaW5kZXBlbmRlbnRseSAoMSlcclxuICAgIHZhbGlkYXRlKGFyZ3MpIHtcclxuICAgICAgICBuZXcgU2ltcGxlU2NoZW1hKHtcclxuICAgICAgICAgICAgY29kZTogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgICAgICAgY3JlYXRlZEF0OiB7IHR5cGU6IERhdGUgfSxcclxuICAgICAgICAgICAgc2Vzc2lvbjogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgICB9KS52YWxpZGF0ZShhcmdzKVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBGYWN0b3Igb3V0IE1ldGhvZCBib2R5IHNvIHRoYXQgaXQgY2FuIGJlIGNhbGxlZCBpbmRlcGVuZGVudGx5ICgzKVxyXG4gICAgcnVuKHsgY29kZSwgY3JlYXRlZEF0LCBzZXNzaW9uIH0pIHtcclxuICAgICAgICBNb2R1bGVzQ29sbGVjdGlvbi5pbnNlcnQoe1xyXG4gICAgICAgICAgICBjb2RlLFxyXG4gICAgICAgICAgICBjcmVhdGVkQXQsXHJcbiAgICAgICAgICAgIHVzZXI6IHRoaXMudXNlcklkLFxyXG4gICAgICAgICAgICBzZXNzaW9uLFxyXG4gICAgICAgIH0pO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyBDYWxsIE1ldGhvZCBieSByZWZlcmVuY2luZyB0aGUgSlMgb2JqZWN0ICg0KVxyXG4gICAgLy8gQWxzbywgdGhpcyBsZXRzIHVzIHNwZWNpZnkgTWV0ZW9yLmFwcGx5IG9wdGlvbnMgb25jZSBpblxyXG4gICAgLy8gdGhlIE1ldGhvZCBpbXBsZW1lbnRhdGlvbiwgcmF0aGVyIHRoYW4gcmVxdWlyaW5nIHRoZSBjYWxsZXJcclxuICAgIC8vIHRvIHNwZWNpZnkgaXQgYXQgdGhlIGNhbGwgc2l0ZS5cclxuICAgIGNhbGwoYXJncywgY2FsbGJhY2spIHtcclxuICAgICAgICBjb25zdCBvcHRpb25zID0ge1xyXG4gICAgICAgICAgICByZXR1cm5TdHViVmFsdWU6IHRydWUsICAgICAvLyAoNSlcclxuICAgICAgICAgICAgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZSAgLy8gKDYpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbYXJnc10sIG9wdGlvbnMsIGNhbGxiYWNrKTtcclxuXHJcbiAgICB9XHJcbn07XHJcblxyXG4iLCJpbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBNb2R1bGVzQ29sbGVjdGlvbiwgUnVuc0NvbGxlY3Rpb24gfSBmcm9tICcuLi9tb2R1bGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCBjcmVhdGVSdW4gPSB7XHJcbiAgbmFtZTogJ3J1bnMuY3JlYXRlJyxcclxuXHJcbiAgLy8gRmFjdG9yIG91dCB2YWxpZGF0aW9uIHNvIHRoYXQgaXQgY2FuIGJlIHJ1biBpbmRlcGVuZGVudGx5ICgxKVxyXG4gIHZhbGlkYXRlKGFyZ3MpIHtcclxuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xyXG4gICAgICBtb2R1bGVJRDogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgaW5wdXQ6IHsgdHlwZTogU3RyaW5nIH0sXHJcbiAgICAgIG91dHB1dDogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgY3JlYXRlZEF0OiB7IHR5cGU6IERhdGUgfSxcclxuICAgIH0pLnZhbGlkYXRlKGFyZ3MpXHJcbiAgfSxcclxuXHJcbiAgLy8gRmFjdG9yIG91dCBNZXRob2QgYm9keSBzbyB0aGF0IGl0IGNhbiBiZSBjYWxsZWQgaW5kZXBlbmRlbnRseSAoMylcclxuICBydW4oeyBtb2R1bGVJRCwgaW5wdXQsIG91dHB1dCwgY3JlYXRlZEF0IH0pIHtcclxuXHJcbiAgICBjb25zdCBtb2R1bGUgPSBNb2R1bGVzQ29sbGVjdGlvbi5maW5kT25lKHsgX2lkOiBtb2R1bGVJRCB9KTtcclxuXHJcbiAgICBpZiAoIW1vZHVsZSkge1xyXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3J1bi5jcmVhdGUubW9kdWxlX25vdF9mb3VuZCcsXHJcbiAgICAgICAgJ1JlZmVyZW5jZWQgbW9kdWxlIGlzIG5vdCBmb3VuZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChtb2R1bGUudXNlciAhPSB0aGlzLnVzZXJJZCkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdydW4uY3JlYXRlLnVuYXV0aG9yaXplZCcsXHJcbiAgICAgICAgJ0Nhbm5vdCByZWZlcmVuY2UgbW9kdWxlIHRoYXQgaXMgbm90IHlvdXJzJyk7XHJcbiAgICB9XHJcblxyXG4gICAgUnVuc0NvbGxlY3Rpb24uaW5zZXJ0KHtcclxuICAgICAgICBtb2R1bGU6IG1vZHVsZUlELFxyXG4gICAgICAgIGlucHV0LFxyXG4gICAgICAgIG91dHB1dCxcclxuICAgICAgICBjcmVhdGVkQXQsXHJcbiAgICB9KTtcclxuXHJcbiAgfSxcclxuXHJcbiAgLy8gQ2FsbCBNZXRob2QgYnkgcmVmZXJlbmNpbmcgdGhlIEpTIG9iamVjdCAoNClcclxuICAvLyBBbHNvLCB0aGlzIGxldHMgdXMgc3BlY2lmeSBNZXRlb3IuYXBwbHkgb3B0aW9ucyBvbmNlIGluXHJcbiAgLy8gdGhlIE1ldGhvZCBpbXBsZW1lbnRhdGlvbiwgcmF0aGVyIHRoYW4gcmVxdWlyaW5nIHRoZSBjYWxsZXJcclxuICAvLyB0byBzcGVjaWZ5IGl0IGF0IHRoZSBjYWxsIHNpdGUuXHJcbiAgY2FsbChhcmdzLCBjYWxsYmFjaykge1xyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlLCAgICAgLy8gKDUpXHJcbiAgICAgIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWUgIC8vICg2KVxyXG4gICAgfVxyXG5cclxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFthcmdzXSwgb3B0aW9ucywgY2FsbGJhY2spO1xyXG4gIH1cclxufTtcclxuXHJcblxyXG4iLCJpbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBTZXNzaW9uc0NvbGxlY3Rpb24gfSBmcm9tICcuLi9tb2R1bGVzJzsgICAgXHJcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCBjcmVhdGVTZXNzaW9uID0ge1xyXG4gICAgbmFtZTogJ3Nlc3Npb24uY3JlYXRlJyxcclxuXHJcbiAgICAvLyBGYWN0b3Igb3V0IHZhbGlkYXRpb24gc28gdGhhdCBpdCBjYW4gYmUgcnVuIGluZGVwZW5kZW50bHkgKDEpXHJcbiAgICB2YWxpZGF0ZShhcmdzKSB7XHJcbiAgICAgICAgbmV3IFNpbXBsZVNjaGVtYSh7XHJcbiAgICAgICAgICAgIG5hbWU6IHsgdHlwZTogU3RyaW5nIH0sXHJcbiAgICAgICAgICAgIHRpdGxlOiB7IHR5cGU6IFN0cmluZyB9LFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgICAgICAgdGVtcGxhdGU6IHsgdHlwZTogU3RyaW5nIH0sXHJcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogeyB0eXBlOiBEYXRlIH0sXHJcbiAgICAgICAgfSkudmFsaWRhdGUoYXJncylcclxuICAgIH0sXHJcblxyXG4gICAgLy8gRmFjdG9yIG91dCBNZXRob2QgYm9keSBzbyB0aGF0IGl0IGNhbiBiZSBjYWxsZWQgaW5kZXBlbmRlbnRseSAoMylcclxuICAgIHJ1bih7IG5hbWUsIHRpdGxlLCBkZXNjcmlwdGlvbiwgdGVtcGxhdGUsIGNyZWF0ZWRBdCB9KSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKCFSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsICdpbnN0cnVjdG9yJykpIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignc2Vzc2lvbi5jcmVhdGUudW5hdXRob3JpemVkJyxcclxuICAgICAgICAgICAgICAgICdPbmx5IHVzZXJzIHdpdGggcm9sZSBpbnN0cnVjdG9yIGNhbiBjcmVhdGUgc2Vzc2lvbnMnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChTZXNzaW9uc0NvbGxlY3Rpb24uZmluZCh7IG5hbWUgfSkuZmV0Y2goKS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3Nlc3Npb24uY3JlYXRlLmR1cGxpY2F0ZScsXHJcbiAgICAgICAgICAgICAgICAnU2Vzc2lvbiBuYW1lIGFscmVhZHkgdGFrZW4nKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIFNlc3Npb25zQ29sbGVjdGlvbi5pbnNlcnQoe1xyXG4gICAgICAgICAgICBuYW1lOiBuYW1lLFxyXG4gICAgICAgICAgICBpbnN0cnVjdGlvbnM6IHtcclxuICAgICAgICAgICAgICAgIHRpdGxlLFxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRlbXBsYXRlLFxyXG4gICAgICAgICAgICB1c2VyczogW10sXHJcbiAgICAgICAgICAgIGNyZWF0ZWRBdCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gQ2FsbCBNZXRob2QgYnkgcmVmZXJlbmNpbmcgdGhlIEpTIG9iamVjdCAoNClcclxuICAgIC8vIEFsc28sIHRoaXMgbGV0cyB1cyBzcGVjaWZ5IE1ldGVvci5hcHBseSBvcHRpb25zIG9uY2UgaW5cclxuICAgIC8vIHRoZSBNZXRob2QgaW1wbGVtZW50YXRpb24sIHJhdGhlciB0aGFuIHJlcXVpcmluZyB0aGUgY2FsbGVyXHJcbiAgICAvLyB0byBzcGVjaWZ5IGl0IGF0IHRoZSBjYWxsIHNpdGUuXHJcbiAgICBjYWxsKGFyZ3MsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgICAgICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlLCAgICAgLy8gKDUpXHJcbiAgICAgICAgICAgIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWUgIC8vICg2KVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW2FyZ3NdLCBvcHRpb25zLCBjYWxsYmFjayk7XHJcbiAgICB9XHJcbn07XHJcblxyXG5cclxuIiwiaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgU25hcHNob3RzQ29sbGVjdGlvbiwgU2Vzc2lvbnNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vbW9kdWxlcyc7XHJcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCBjcmVhdGVTbmFwc2hvdCA9IHtcclxuICBuYW1lOiAnc25hcHNob3RzLmNyZWF0ZScsXHJcblxyXG4gIC8vIEZhY3RvciBvdXQgdmFsaWRhdGlvbiBzbyB0aGF0IGl0IGNhbiBiZSBydW4gaW5kZXBlbmRlbnRseSAoMSlcclxuICB2YWxpZGF0ZShhcmdzKSB7XHJcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcclxuICAgICAgY29kZTogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgc2Vzc2lvbjogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgdXNlcjogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgY3JlYXRlZEF0OiB7IHR5cGU6IERhdGUgfSxcclxuICAgIH0pLnZhbGlkYXRlKGFyZ3MpXHJcbiAgfSxcclxuXHJcbiAgLy8gRmFjdG9yIG91dCBNZXRob2QgYm9keSBzbyB0aGF0IGl0IGNhbiBiZSBjYWxsZWQgaW5kZXBlbmRlbnRseSAoMylcclxuICBydW4oeyBjb2RlLCBzZXNzaW9uLCB1c2VyLCBjcmVhdGVkQXQgfSkge1xyXG4gICAgICBcclxuICAgIGlmIChTZXNzaW9uc0NvbGxlY3Rpb24uZmluZCh7IG5hbWU6IHNlc3Npb24gfSkuZmV0Y2goKS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3NuYXBzaG90cy5jcmVhdGUuc2Vzc2lvbl9ub3RfZm91bmQnLFxyXG4gICAgICAgICdSZWZlcmVuY2VkIHNlc3Npb24gaXMgbm90IGZvdW5kJyk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHVzZXIgIT0gdGhpcy51c2VySWQgJiYgIVJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgJ2luc3RydWN0b3InKSkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdydW4uY3JlYXRlLnVuYXV0aG9yaXplZCcsXHJcbiAgICAgICAgJ0Nhbm5vdCBjcmVhdGUgc25hcHNob3QgdGhhdCBpcyBub3QgeW91cnMgd2l0aCBjdXJyZW50IHBlcm1pc3Npb25zJyk7XHJcbiAgICB9XHJcblxyXG4gICAgU25hcHNob3RzQ29sbGVjdGlvbi5pbnNlcnQoe1xyXG4gICAgICAgIGNvZGUsXHJcbiAgICAgICAgc2Vzc2lvbixcclxuICAgICAgICB1c2VyLFxyXG4gICAgICAgIGNyZWF0ZWRBdCxcclxuICAgIH0pO1xyXG5cclxuICB9LFxyXG5cclxuICAvLyBDYWxsIE1ldGhvZCBieSByZWZlcmVuY2luZyB0aGUgSlMgb2JqZWN0ICg0KVxyXG4gIC8vIEFsc28sIHRoaXMgbGV0cyB1cyBzcGVjaWZ5IE1ldGVvci5hcHBseSBvcHRpb25zIG9uY2UgaW5cclxuICAvLyB0aGUgTWV0aG9kIGltcGxlbWVudGF0aW9uLCByYXRoZXIgdGhhbiByZXF1aXJpbmcgdGhlIGNhbGxlclxyXG4gIC8vIHRvIHNwZWNpZnkgaXQgYXQgdGhlIGNhbGwgc2l0ZS5cclxuICBjYWxsKGFyZ3MsIGNhbGxiYWNrKSB7XHJcbiAgICBjb25zdCBvcHRpb25zID0ge1xyXG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWUsICAgICAvLyAoNSlcclxuICAgICAgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZSAgLy8gKDYpXHJcbiAgICB9XHJcblxyXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW2FyZ3NdLCBvcHRpb25zLCBjYWxsYmFjayk7XHJcbiAgfVxyXG59O1xyXG5cclxuXHJcbiIsImltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IEZlZWRiYWNrQ29sbGVjdGlvbiwgTW9kdWxlc0NvbGxlY3Rpb24gfSBmcm9tICcuLi9tb2R1bGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCByYXRlRmVlZGJhY2sgPSB7XHJcbiAgbmFtZTogJ2ZlZWRiYWNrLnJhdGUnLFxyXG5cclxuICAvLyBGYWN0b3Igb3V0IHZhbGlkYXRpb24gc28gdGhhdCBpdCBjYW4gYmUgcnVuIGluZGVwZW5kZW50bHkgKDEpXHJcbiAgdmFsaWRhdGUoYXJncykge1xyXG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XHJcbiAgICAgIGZlZWRiYWNrSUQ6IHsgdHlwZTogU3RyaW5nIH0sXHJcbiAgICAgIHJhdGluZzogeyB0eXBlOiBCb29sZWFuIH0sXHJcbiAgICAgIGNyZWF0ZWRBdDogeyB0eXBlOiBEYXRlIH0sXHJcbiAgICB9KS52YWxpZGF0ZShhcmdzKVxyXG4gIH0sXHJcblxyXG4gIC8vIEZhY3RvciBvdXQgTWV0aG9kIGJvZHkgc28gdGhhdCBpdCBjYW4gYmUgY2FsbGVkIGluZGVwZW5kZW50bHkgKDMpXHJcbiAgcnVuKHsgZmVlZGJhY2tJRCwgcmF0aW5nLCBjcmVhdGVkQXQgfSkge1xyXG5cclxuICAgIGNvbnN0IGZlZWRiYWNrID0gRmVlZGJhY2tDb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IGZlZWRiYWNrSUQgfSk7XHJcbiAgICBjb25zdCBtb2R1bGVJRCA9IGZlZWRiYWNrLm1vZHVsZTtcclxuXHJcbiAgICBjb25zdCBtb2R1bGUgPSBNb2R1bGVzQ29sbGVjdGlvbi5maW5kT25lKHsgX2lkOiBtb2R1bGVJRCB9KTtcclxuICAgIGNvbnN0IG93bmVyID0gbW9kdWxlLnVzZXI7XHJcblxyXG4gICAgaWYgKG93bmVyICE9IHRoaXMudXNlcklkKSB7XHJcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2ZlZWRiYWNrLnJhdGUudW5hdXRob3JpemVkJyxcclxuICAgICAgICAnQ2Fubm90IHJhdGUgZmVlZGJhY2sgaW50ZW5kZWQgZm9yIHVzZXJzIG90aGVyIHRoYW4geW91cnNlbGYnKTtcclxuICAgIH1cclxuXHJcbiAgICBGZWVkYmFja0NvbGxlY3Rpb24udXBkYXRlKHsgX2lkOiBmZWVkYmFja0lEIH0sIHtcclxuICAgICAgJHNldDoge1xyXG4gICAgICAgIGhlbHBmdWw6IHJhdGluZyxcclxuICAgICAgICByYXRlZEF0OiBjcmVhdGVkQXQsXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICB9LFxyXG5cclxuICAvLyBDYWxsIE1ldGhvZCBieSByZWZlcmVuY2luZyB0aGUgSlMgb2JqZWN0ICg0KVxyXG4gIC8vIEFsc28sIHRoaXMgbGV0cyB1cyBzcGVjaWZ5IE1ldGVvci5hcHBseSBvcHRpb25zIG9uY2UgaW5cclxuICAvLyB0aGUgTWV0aG9kIGltcGxlbWVudGF0aW9uLCByYXRoZXIgdGhhbiByZXF1aXJpbmcgdGhlIGNhbGxlclxyXG4gIC8vIHRvIHNwZWNpZnkgaXQgYXQgdGhlIGNhbGwgc2l0ZS5cclxuICBjYWxsKGFyZ3MsIGNhbGxiYWNrKSB7XHJcbiAgICBjb25zdCBvcHRpb25zID0ge1xyXG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWUsICAgICAvLyAoNSlcclxuICAgICAgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZSAgLy8gKDYpXHJcbiAgICB9XHJcblxyXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW2FyZ3NdLCBvcHRpb25zLCBjYWxsYmFjayk7XHJcbiAgfVxyXG59O1xyXG5cclxuXHJcbiIsImltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vZHVsZXNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vbW9kdWxlcyc7XHJcblxyXG4vLyBodHRwczovL2d1aWRlLm1ldGVvci5jb20vbWV0aG9kcy5odG1sI2FkdmFuY2VkLWJvaWxlcnBsYXRlXHJcbmV4cG9ydCBjb25zdCB1cGRhdGVNb2R1bGUgPSB7XHJcbiAgbmFtZTogJ21vZHVsZXMudXBkYXRlJyxcclxuXHJcbiAgLy8gRmFjdG9yIG91dCB2YWxpZGF0aW9uIHNvIHRoYXQgaXQgY2FuIGJlIHJ1biBpbmRlcGVuZGVudGx5ICgxKVxyXG4gIHZhbGlkYXRlKGFyZ3MpIHtcclxuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xyXG4gICAgICBtb2R1bGVJRDogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgY29kZTogeyB0eXBlOiBTdHJpbmcgfSxcclxuICAgICAgY3JlYXRlZEF0OiB7IHR5cGU6IERhdGUgfSxcclxuICAgIH0pLnZhbGlkYXRlKGFyZ3MpXHJcbiAgfSxcclxuXHJcbiAgLy8gRmFjdG9yIG91dCBNZXRob2QgYm9keSBzbyB0aGF0IGl0IGNhbiBiZSBjYWxsZWQgaW5kZXBlbmRlbnRseSAoMylcclxuICBydW4oeyBtb2R1bGVJRCwgY29kZSwgY3JlYXRlZEF0IH0pIHtcclxuICAgIFxyXG4gICAgY29uc3QgbW9kdWxlID0gTW9kdWxlc0NvbGxlY3Rpb24uZmluZE9uZSh7IF9pZDogbW9kdWxlSUQgfSk7XHJcblxyXG4gICAgaWYgKG1vZHVsZS51c2VyICE9IHRoaXMudXNlcklkKSB7XHJcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ21vZHVsZXMudXBkYXRlLnVuYXV0aG9yaXplZCcsXHJcbiAgICAgICAgJ0Nhbm5vdCBlZGl0IG1vZHVsZSB0aGF0IGlzIG5vdCB5b3VycycpO1xyXG4gICAgfVxyXG5cclxuICAgIE1vZHVsZXNDb2xsZWN0aW9uLnVwZGF0ZSh7IF9pZDogbW9kdWxlSUQgfSwge1xyXG4gICAgICAkc2V0OiB7XHJcbiAgICAgICAgY29kZSxcclxuICAgICAgICBjcmVhdGVkQXQsXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICB9LFxyXG5cclxuICAvLyBDYWxsIE1ldGhvZCBieSByZWZlcmVuY2luZyB0aGUgSlMgb2JqZWN0ICg0KVxyXG4gIC8vIEFsc28sIHRoaXMgbGV0cyB1cyBzcGVjaWZ5IE1ldGVvci5hcHBseSBvcHRpb25zIG9uY2UgaW5cclxuICAvLyB0aGUgTWV0aG9kIGltcGxlbWVudGF0aW9uLCByYXRoZXIgdGhhbiByZXF1aXJpbmcgdGhlIGNhbGxlclxyXG4gIC8vIHRvIHNwZWNpZnkgaXQgYXQgdGhlIGNhbGwgc2l0ZS5cclxuICBjYWxsKGFyZ3MsIGNhbGxiYWNrKSB7XHJcbiAgICBjb25zdCBvcHRpb25zID0ge1xyXG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWUsICAgICAvLyAoNSlcclxuICAgICAgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZSAgLy8gKDYpXHJcbiAgICB9XHJcblxyXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW2FyZ3NdLCBvcHRpb25zLCBjYWxsYmFjayk7XHJcbiAgfVxyXG59O1xyXG5cclxuXHJcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuXHJcbmV4cG9ydCBjb25zdCBTZXNzaW9uc0NvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc2Vzc2lvbnMnKTsgLy8gd2hpY2ggbGFiIG9yIGV4ZXJjaXNlIHN0dWRlbnRzIGFyZSB3b3JraW5nIG9uXHJcbmV4cG9ydCBjb25zdCBTbmFwc2hvdHNDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3NuYXBzaG90cycpOyAvLyBoaXN0b3J5IG9mIHN0dWRlbnQncyBjb2RlXHJcbmV4cG9ydCBjb25zdCBNb2R1bGVzQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtb2R1bGVzJyk7IC8vIGN1cnJlbnQgc25hcHNob3Qgb2YgY29kZSwgdXBkYXRlZCBtb3JlIGZyZXF1ZW50bHkgdGhhbiBzbmFwc2hvdHMgY29sbGVjdGlvblxyXG5leHBvcnQgY29uc3QgUnVuc0NvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncnVucycpO1xyXG5leHBvcnQgY29uc3QgRmVlZGJhY2tDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZlZWRiYWNrJyk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xyXG5pbXBvcnQgeyBSdW5zQ29sbGVjdGlvbiwgTW9kdWxlc0NvbGxlY3Rpb24sIFNuYXBzaG90c0NvbGxlY3Rpb24sIEZlZWRiYWNrQ29sbGVjdGlvbiwgU2Vzc2lvbnNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vaW1wb3J0cy9hcGkvbW9kdWxlcyc7XHJcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcclxuaW1wb3J0IHsgY3JlYXRlRmVlZGJhY2sgfSBmcm9tICcuLi9pbXBvcnRzL2FwaS9tZXRob2RzL2NyZWF0ZUZlZWRiYWNrJztcclxuaW1wb3J0IHsgY3JlYXRlTW9kdWxlIH0gZnJvbSAnLi4vaW1wb3J0cy9hcGkvbWV0aG9kcy9jcmVhdGVNb2R1bGUnO1xyXG5pbXBvcnQgeyBjcmVhdGVSdW4gfSBmcm9tICcuLi9pbXBvcnRzL2FwaS9tZXRob2RzL2NyZWF0ZVJ1bic7XHJcbmltcG9ydCB7IGNyZWF0ZVNlc3Npb24gfSBmcm9tICcuLi9pbXBvcnRzL2FwaS9tZXRob2RzL2NyZWF0ZVNlc3Npb24nO1xyXG5pbXBvcnQgeyBjcmVhdGVTbmFwc2hvdCB9IGZyb20gJy4uL2ltcG9ydHMvYXBpL21ldGhvZHMvY3JlYXRlU25hcHNob3QnO1xyXG5pbXBvcnQgeyByYXRlRmVlZGJhY2sgfSBmcm9tICcuLi9pbXBvcnRzL2FwaS9tZXRob2RzL3JhdGVGZWVkYmFjayc7XHJcbmltcG9ydCB7IHVwZGF0ZU1vZHVsZSB9IGZyb20gJy4uL2ltcG9ydHMvYXBpL21ldGhvZHMvdXBkYXRlTW9kdWxlJztcclxuaW1wb3J0IHsgYWRkU2Vzc2lvblVzZXIgfSBmcm9tICcuLi9pbXBvcnRzL2FwaS9tZXRob2RzL2FkZFNlc3Npb25Vc2VyJztcclxuXHJcblxyXG4vLyBQbGFjZWhvbGRlciBmb3IgYWN0dWFsIGxvZ2luIGNyZWRlbnRpYWxzXHJcbi8vIEFsbCBwYXNzd29yZHMgYXJlIFwicGFzc3dvcmRcIlxyXG5leHBvcnQgY29uc3QgSU5TVFJVQ1RPUiA9IFwiaW5zdHJ1Y3RvclwiO1xyXG5jb25zdCBTVFVERU5UUyA9IFtdO1xyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gIC8vIFRPRE86IFdoeSBpbmNsdWRlIGVtcHR5IGFycmF5IG9mIHN0dWRlbnRzPz8/XHJcbiAgWy4uLlNUVURFTlRTLCBJTlNUUlVDVE9SXS5mb3JFYWNoKChuYW1lKSA9PiB7XHJcbiAgICBpZiAoIUFjY291bnRzLmZpbmRVc2VyQnlVc2VybmFtZShuYW1lKSkge1xyXG4gICAgICBBY2NvdW50cy5jcmVhdGVVc2VyKHtcclxuICAgICAgICB1c2VybmFtZTogbmFtZSxcclxuICAgICAgICBwYXNzd29yZDogXCJwYXNzd29yZFwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLy8gY3JlYXRlIHJvbGVzXHJcbiAgaWYgKCFNZXRlb3Iucm9sZXMuZmluZE9uZSh7IF9pZDogJ3N0dWRlbnQnIH0pKSB7XHJcbiAgICBSb2xlcy5jcmVhdGVSb2xlKCdzdHVkZW50Jyk7XHJcbiAgfVxyXG5cclxuICBpZiAoIU1ldGVvci5yb2xlcy5maW5kT25lKHsgX2lkOiAnaW5zdHJ1Y3RvcicgfSkpIHtcclxuICAgIFJvbGVzLmNyZWF0ZVJvbGUoJ2luc3RydWN0b3InKTtcclxuICB9XHJcblxyXG4gIC8vIGFzc2lnbiByb2xlc1xyXG4gIGNvbnN0IGluc3RydWN0b3JJRCA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgdXNlcm5hbWU6IFwiaW5zdHJ1Y3RvclwiIH0pLl9pZDtcclxuICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXMoaW5zdHJ1Y3RvcklELCAnaW5zdHJ1Y3RvcicpO1xyXG5cclxuICAvLyBwcmV2ZW50IGRpcmVjdCBjbGllbnQtc2lkZSBkYXRhYmFzZSBhY2Nlc3NcclxuICAvLyBNZXRlb3IgcmVjb21tZW5kcyB0byB1c2UgTWV0aG9kcyBpbnN0ZWFkIGZvciBzZWN1cml0eVxyXG4gIE1vZHVsZXNDb2xsZWN0aW9uLmRlbnkoe1xyXG4gICAgaW5zZXJ0KCkgeyByZXR1cm4gdHJ1ZTsgfSxcclxuICAgIHVwZGF0ZSgpIHsgcmV0dXJuIHRydWU7IH0sXHJcbiAgICByZW1vdmUoKSB7IHJldHVybiB0cnVlOyB9LFxyXG4gIH0pO1xyXG5cclxuICBTZXNzaW9uc0NvbGxlY3Rpb24uZGVueSh7XHJcbiAgICBpbnNlcnQoKSB7IHJldHVybiB0cnVlOyB9LFxyXG4gICAgdXBkYXRlKCkgeyByZXR1cm4gdHJ1ZTsgfSxcclxuICAgIHJlbW92ZSgpIHsgcmV0dXJuIHRydWU7IH0sXHJcbiAgfSk7XHJcblxyXG4gIFNuYXBzaG90c0NvbGxlY3Rpb24uZGVueSh7XHJcbiAgICBpbnNlcnQoKSB7IHJldHVybiB0cnVlOyB9LFxyXG4gICAgdXBkYXRlKCkgeyByZXR1cm4gdHJ1ZTsgfSxcclxuICAgIHJlbW92ZSgpIHsgcmV0dXJuIHRydWU7IH0sXHJcbiAgfSk7XHJcblxyXG4gIEZlZWRiYWNrQ29sbGVjdGlvbi5kZW55KHtcclxuICAgIGluc2VydCgpIHsgcmV0dXJuIHRydWU7IH0sXHJcbiAgICB1cGRhdGUoKSB7IHJldHVybiB0cnVlOyB9LFxyXG4gICAgcmVtb3ZlKCkgeyByZXR1cm4gdHJ1ZTsgfSxcclxuICB9KTtcclxuXHJcbiAgUnVuc0NvbGxlY3Rpb24uZGVueSh7XHJcbiAgICBpbnNlcnQoKSB7IHJldHVybiB0cnVlOyB9LFxyXG4gICAgdXBkYXRlKCkgeyByZXR1cm4gdHJ1ZTsgfSxcclxuICAgIHJlbW92ZSgpIHsgcmV0dXJuIHRydWU7IH0sXHJcbiAgfSk7XHJcblxyXG4gIE1ldGVvci5wdWJsaXNoKCd1c2VyRGF0YScsIGZ1bmN0aW9uICgpIHtcclxuICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7fSwge1xyXG4gICAgICBmaWVsZHM6IHsgdXNlcm5hbWU6IDEsIGNyZWF0ZWRBdDogMSwgX2lkOiAxIH1cclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBNZXRlb3IucHVibGlzaCgnc2Vzc2lvbnMnLCBmdW5jdGlvbiAoKSB7XHJcbiAgICByZXR1cm4gU2Vzc2lvbnNDb2xsZWN0aW9uLmZpbmQoKTtcclxuICB9KTtcclxuXHJcbiAgTWV0ZW9yLnB1Ymxpc2goJ21vZHVsZXMnLCBmdW5jdGlvbiAoKSB7XHJcbiAgICBjb25zdCB1c2VySUQgPSB0aGlzLnVzZXJJZDtcclxuICAgIC8vIGlmIGluc3RydWN0b3IsIHJldHVybiBhbGwgbW9kdWxlcywgZWxzZSBvbmx5IHJldHVybiBtb2R1bGVzIG93bmVkIGJ5IHVzZXIgbWFraW5nIHRoZSByZXF1ZXN0XHJcbiAgICByZXR1cm4gTW9kdWxlc0NvbGxlY3Rpb24uZmluZChSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsICdpbnN0cnVjdG9yJykgPyB7fSA6IHsgdXNlcjogdXNlcklEIH0pO1xyXG4gIH0pO1xyXG5cclxuICBNZXRlb3IucHVibGlzaCgncnVucycsIGZ1bmN0aW9uICgpIHtcclxuICAgIGNvbnN0IHVzZXJJRCA9IHRoaXMudXNlcklkO1xyXG4gICAgXHJcbiAgICAvLyBpZiBpbnN0cnVjdG9yLCByZXR1cm4gYWxsIHJ1bnMsIGVsc2Ugb25seSByZXR1cm4gbW9kdWxlcyBvd25lZCBieSB1c2VyIG1ha2luZyB0aGUgcmVxdWVzdFxyXG4gICAgY29uc3QgbW9kdWxlcyA9IE1vZHVsZXNDb2xsZWN0aW9uLmZpbmQoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCAnaW5zdHJ1Y3RvcicpID8ge30gOiB7IHVzZXI6IHVzZXJJRCB9KS5mZXRjaCgpO1xyXG4gICAgcmV0dXJuIFJ1bnNDb2xsZWN0aW9uLmZpbmQoeyBtb2R1bGU6IHsgJGluOiBtb2R1bGVzLm1hcChtb2R1bGUgPT4gbW9kdWxlLl9pZCkgfX0pO1xyXG4gIH0pO1xyXG5cclxuICBNZXRlb3IucHVibGlzaCgnc25hcHNob3RzJywgZnVuY3Rpb24gKCkge1xyXG4gICAgY29uc3QgdXNlcklEID0gdGhpcy51c2VySWQ7XHJcbiAgICAvLyBpZiBpbnN0cnVjdG9yLCByZXR1cm4gYWxsIHNuYXBzaG90cywgZWxzZSBvbmx5IHJldHVybiBtb2R1bGVzIG93bmVkIGJ5IHVzZXIgbWFraW5nIHRoZSByZXF1ZXN0XHJcbiAgICByZXR1cm4gU25hcHNob3RzQ29sbGVjdGlvbi5maW5kKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgJ2luc3RydWN0b3InKSA/IHt9IDogeyB1c2VyOiB1c2VySUQgfSk7XHJcbiAgfSk7XHJcblxyXG4gIE1ldGVvci5wdWJsaXNoKCdmZWVkYmFjaycsIGZ1bmN0aW9uICgpIHtcclxuICAgIGNvbnN0IHVzZXJJRCA9IHRoaXMudXNlcklkO1xyXG4gICAgY29uc3Qgc3R1ZGVudE1vZHVsZXMgPSBNb2R1bGVzQ29sbGVjdGlvbi5maW5kKHsgdXNlcjogdXNlcklEIH0pLmZldGNoKCk7XHJcbiAgICByZXR1cm4gRmVlZGJhY2tDb2xsZWN0aW9uLmZpbmQoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCAnaW5zdHJ1Y3RvcicpID8ge30gOiB7IG1vZHVsZTogeyAkaW46IHN0dWRlbnRNb2R1bGVzLm1hcChtID0+IG0uX2lkKSB9IH0pXHJcbiAgfSk7XHJcblxyXG4gIC8vIFZlcnkgaGVscGZ1bCBmb3IgZ2V0dGluZyBzdGFydGVkIHdpdGggTWV0ZW9yIE1ldGhvZHMgaHR0cHM6Ly9ndWlkZS5tZXRlb3IuY29tL21ldGhvZHMuaHRtbCNhZHZhbmNlZC1ib2lsZXJwbGF0ZVxyXG4gIGNvbnN0IG1ldGhvZHMgPSBbY3JlYXRlRmVlZGJhY2ssIGNyZWF0ZU1vZHVsZSwgY3JlYXRlUnVuLCBjcmVhdGVTZXNzaW9uLCBjcmVhdGVTbmFwc2hvdCwgcmF0ZUZlZWRiYWNrLCB1cGRhdGVNb2R1bGUsIGFkZFNlc3Npb25Vc2VyXTtcclxuXHJcbiAgbWV0aG9kcy5mb3JFYWNoKG1ldGhvZCA9PiB7XHJcbiAgICAvLyByZWdpc3RlciBlYWNoIG1ldGhvZCB3aXRoIE1ldGVvcidzIEREUCBzeXN0ZW1cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgW21ldGhvZC5uYW1lXTogZnVuY3Rpb24gKGFyZ3MpIHtcclxuICAgICAgICBtZXRob2QudmFsaWRhdGUuY2FsbCh0aGlzLCBhcmdzKTtcclxuICAgICAgICBtZXRob2QucnVuLmNhbGwodGhpcywgYXJncyk7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfSk7XHJcblxyXG59KTsiXX0=
